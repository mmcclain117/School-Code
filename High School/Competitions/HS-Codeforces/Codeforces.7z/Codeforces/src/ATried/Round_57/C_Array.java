package ATried.Round_57;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_Array {

    /**
     * Tags: Combinatorics, Math,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
