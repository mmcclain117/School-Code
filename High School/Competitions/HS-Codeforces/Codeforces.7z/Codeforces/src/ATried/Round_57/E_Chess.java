package ATried.Round_57;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class E_Chess {

    /**
     * Tags: Math, Shortest Paths
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int k = scan.nextInt(); // Max Number of Knight Moves
        int n = scan.nextInt(); // # of deleted columns
        int grid[][] = new int[8][8];
        for (int i = 0; i < 8; i++) {
            for (int ii = 0; ii < 8; ii++) {
                grid[i][ii] = 1; // Nothing
            }
        }
        for (int i = 0; i < n; i++) {
            int x = scan.nextInt();
            int y = scan.nextInt();
            grid[y][x] = 2; // Not avaliable
        }
        Move(grid, 0, 0, k);
        int con = 0;
        for (int i = 0; i < 8; i++) {
            for (int ii = 0; ii < 8; ii++) {
                out.print(grid[i][ii] + " ");
                if (grid[i][ii] == 3) {
                    con++;
                }
            }
            out.println();
        }
        out.println(con);
    }

    public static void Move(int g[][], int x, int y, int k) {
        if (k >= 0) {
            if (y - 2 >= 0) {
                if (x - 1 >= 0) {
                    if (g[y - 2][x - 1] == 1) { // Up Left
                        g[y - 2][x - 1] = 3;
                        Move(g, y - 2, x - 1, k - 1);
                    }
                }
                if (x + 1 < 8) {
                    if (g[y - 2][x + 1] == 1) { // Up Right
                        g[y - 2][x + 1] = 3;
                        Move(g, y - 2, x + 1, k - 1);
                    }
                }
            }
            if (x + 2 < 8) {
                if (y - 1 >= 0) {
                    if (g[y - 1][x + 2] == 1) { // Right Up
                        g[y - 1][x + 2] = 3;
                        Move(g, y - 1, x + 2, k - 1);
                    }
                }
                if (y + 1 < 8) {
                    if (g[y + 1][x + 2] == 1) { // Right Down
                        g[y + 1][x + 2] = 3;
                        Move(g, y + 1, x + 2, k - 1);
                    }
                }
            }
            if (y + 2 < 8) {
                if (x + 1 < 8) {
                    if (g[y + 2][x + 1] == 1) { // Down Right
                        g[y + 2][x + 1] = 3;
                        Move(g, y + 2, x + 1, k - 1);
                    }
                }
                if (x - 1 >= 0) {
                    if (g[y + 2][x - 1] == 1) { // Down Left
                        g[y + 2][x - 1] = 3;
                        Move(g, y + 2, x - 1, k - 1);
                    }
                }
            }
            if (x - 2 >= 0) {
                if (y + 1 < 8) {
                    if (g[y + 1][x - 2] == 1) { // Left Down
                        g[y + 1][x - 2] = 3;
                        Move(g, y + 1, x - 2, k - 1);
                    }
                }
                if (y - 1 >= 0) {
                    if (g[y - 1][x - 2] == 1) { // Left Up
                        g[y - 1][x - 2] = 3;
                        Move(g, y - 1, x - 2, k - 1);
                    }
                }
            }
        }
    }
}
