package ATried.Round_81;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class E_Pairs {

    /**
     * Tags: Dfs and Similar, Dp, Dsu, Graphs, Implementation, Trees
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        for (int i = 0; i < n; i++) {
            int f = scan.nextInt();
            int s = scan.nextInt();
        }
    }
}
