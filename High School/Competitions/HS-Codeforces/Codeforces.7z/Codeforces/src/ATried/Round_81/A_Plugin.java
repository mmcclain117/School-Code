package ATried.Round_81;

import static java.lang.System.out;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;

public class A_Plugin {

    /**
     * Tags: Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        String a = scan.nextLine();
        String copy = a;
        char ch[] = a.toCharArray();
        ArrayList<String> ar = new ArrayList();
        for (int i = 0; i < ch.length; i++) {
            ar.add(ch[i] + "");
        }
        int con = 1;
        while (con < ar.size() && ar.size() > 1) {
            if (con <= 0) {
                con = 1;
            }
            if (ar.get(con - 1).equals(ar.get(con))) {
                copy = copy.replaceAll(ar.get(con) + ar.get(con), "");
                ar.remove(con - 1);
                ar.remove(con - 1);
                con -= 2;
            }
            con++;
        }
        for (int i = 0; i < ar.size(); i++) {
            out.print(ar.get(i));
        }
        out.println();
//        out.println(Arrays.toString(ar.toArray()));
    }
}
