package ATried.Round_16;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_Monitor {

    /**
     * Tags: Binary Search, Number Theory
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int a = scan.nextInt();
        int b = scan.nextInt();
        int x = scan.nextInt();
        int y = scan.nextInt();
        if (x > a || y > b) {
            System.out.println("0 0");
        } else if (x == a && y == b) {
            System.out.println(a + " " + b);
        } else {
            if (a % x == 0) {
                int t = a / x;
                int yy = t * y;
                if (yy > b) { // Check if new one is bigger
                    System.out.println("First not working");
                } else {
                    System.out.println(a + " " + yy);
                }
            } else if (b % y == 0) {
                int t = b / y;
                int xx = t * x;
                if (xx > a) { // Check if new one is bigger
                    System.out.println("Not Working");
                } else {
                    System.out.println(xx + " " + b);
                }
            }
        }
    }
}
