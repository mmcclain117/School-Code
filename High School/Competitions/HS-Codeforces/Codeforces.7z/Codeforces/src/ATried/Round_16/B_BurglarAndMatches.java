package ATried.Round_16;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_BurglarAndMatches {

    /**
     * Tags: Greedy, Implementation, Sortings
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int m = scan.nextInt();
        scan.nextLine();
        int sum = 0;
        for (int i = 0; i < m; i++) {
            int a = scan.nextInt(); // Matches
            int b = scan.nextInt(); // Number of matches in box
            if (b > n) {
                sum += a * n;
            } else {
                sum += a * b;
            }
        }
        System.out.println(sum);
    }
}
