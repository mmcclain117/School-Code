package ATried.Round_16;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class D_Logging {

    /**
     * Tags: Implementation, Strings Doesnt always count the first one
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        scan.nextLine();
        int lasHour = 0; // Last Time hour
        int lasMin = 0; // Last time Minuet
        int count = 0;
//        Pattern p = Pattern.compile("[(\\d+):(\\d+)([ap])] : ");
        for (int i = 0; i < n; i++) {
            /*
             String a = scan.nextLine();
             Pattern p = Pattern.compile("(\\d+)\\:(\\d+) (.)\\.(.)\\.: ([ a-zA-Z+ ])");
             Matcher m = p.matcher(a.substring(1));
             //            System.out.println(m.find(1));
             System.out.println(m.groupCount());
             int con = 0;
             //            System.out.println(m.group(0));
             //            System.out.println(m.end());
             //            m.start();
             while(m.matches()) {
             //            while (m.hitEnd()) {
             System.out.println(m.start(4));
             //                System.out.println(m.group(con));
             con++;
             }
             */
            String a = scan.nextLine().substring(1);
            a = a.replace("]", "");
            String[] b = a.split("[ :]");
            int hour = Integer.parseInt(b[0]);
            int min = Integer.parseInt(b[1]);
            if ("p.m.".equals(b[2])) {
                hour += 12;
            }
            if (hour == 12) {
                hour = 24;
            }
            if (hour == 24) {
                hour = 0;
            }
//            if (hour == 24) {
//                hour = 0;
//                min = 0;
//                count++;
//            }
            if (i != 0) {
                if (lasHour == hour) {
                    if (lasMin > min) {
                        count++;
                    }
                } else if (lasHour > hour) {
                    count++;
                }
            }
            System.out.println(lasHour + " " + hour + " " + count);
            lasHour = hour;
            lasMin = min;

//            count++;
//            int con = 5;
//            String fin = b[4];
//            while (con < b.length) {
//                fin += " " + b[con];
//                con++;
//            }
//            System.out.println(hour + " " + min + " " + fin);
//            for (String c : b) {
//                System.out.println(c);
//            }
        }
        System.out.println(count + 1);
    }
}
