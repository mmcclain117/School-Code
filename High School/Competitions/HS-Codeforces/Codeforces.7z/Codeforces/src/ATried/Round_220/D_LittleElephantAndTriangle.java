package ATried.Round_220;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class D_LittleElephantAndTriangle {

    /**
     * Tags: Theorem, Geometry, Math,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
