package ATried.Round_29;

import java.util.Scanner;

public class B_TrafficLights {

    /**
     * Tags: Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int l = scan.nextInt(); // Distance between A and B
        int d = scan.nextInt(); // Distance from A to traffic Light
        int v = scan.nextInt(); // Speed of the car (Meters per second)
        int g = scan.nextInt(); // Duration of Green light
        int r = scan.nextInt(); // Duration of Red lIght
        double fin = 0.0; // Final
        double ta = 0.0000000; // Time to light

        int ex = l - d; // Length after light
        fin += (double) ex / (double) v;
        System.out.println(fin);
    }
}
