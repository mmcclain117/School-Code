package ATried.Round_29;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_MailStamps {

    /**
     * Tags: Structures, Similar, Graphs, Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
