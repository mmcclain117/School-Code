package ATried.Round_102;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class D_Buses {

    /**
     * Tags: Binary Search, Data Structures, Dynamic Programming (Dp)
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int m = scan.nextInt();
    }
}
