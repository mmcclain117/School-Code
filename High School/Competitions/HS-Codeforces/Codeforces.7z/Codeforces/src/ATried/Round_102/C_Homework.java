package ATried.Round_102;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_Homework {

    /**
     * Tags: Greedy
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        String a = scan.next();
        int n = scan.nextInt();

    }
}
