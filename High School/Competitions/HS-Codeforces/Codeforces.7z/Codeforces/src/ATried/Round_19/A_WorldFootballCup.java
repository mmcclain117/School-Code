package ATried.Round_19;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;
import java.util.Arrays;

public class A_WorldFootballCup {

    /**
     * Tags: Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Amount of teams
        scan.nextLine();
        String a[] = new String[n]; // Teams
        int sc[] = new int[n]; // Scores
        int t[] = new int[n]; // Tally of win, Draw, Lose
        for (int i = 0; i < n; i++) {
            a[i] = scan.nextLine();
            sc[i] = 0;
            t[i] = 0;
        }
        int ma = n * (n - 1) / 2; // Match Numbers
        for (int i = 0; i < ma; i++) {
            String mat = scan.nextLine();
            int sep = mat.indexOf("-"); // Team Seperator placement
            int w = mat.indexOf(" "); // Index of whitespace
            String n1 = mat.substring(0, sep); // Team 1
            String n2 = mat.substring(sep + 1, w); // Team 2
//            System.out.println("Team 1: " + n1 + "\nTeam 2: " + n2);
            mat = mat.substring(w);
            int s = mat.indexOf(":"); // Index of :
            int t1 = Integer.parseInt(mat.substring(1, s)); // Team 1 Score
            int t2 = Integer.parseInt(mat.substring(s + 1)); // Team 2 Score
//            System.out.println("S1: " + t1);
//            System.out.println("S2: " + t2);
            int ta1 = ind(n1, a);
            int ta2 = ind(n2, a);
            sc[ta1] += t1; // Adds score to Scores
            sc[ta2] += t2; // Adds score to Scores
            if (t1 == t2) {// They tie
                t[ta1]++;
                t[ta2]++;
            } else if (t1 > t2) { // Team 1 Wins
                t[ta1] += 3;
            } else if (t2 > t1) { // Team 2 Wins
                t[ta2] += 3;
            }
        }
        int numb = n / 2;
        int con = 0;
        int tt[] = Arrays.copyOfRange(t, 0, n);
        Arrays.sort(tt);
        String te[] = new String[numb];
        for (int ii = n - 1; ii >= numb; ii--) {
//            int ind = Arrays.binarySearch(t, tt[ii]);
            int ind = se(t, tt[ii]);
//            if(tt[ind] ==(tt[ind + 1])) { // If there is a tie
//                
//            } 
            te[con] = a[ind];
            con++;
//            System.out.println(a[ind]);
        }
        Arrays.sort(te);
        for (int i = 0; i < te.length; i++) {
            System.out.println(te[i]);
        }
//        for (int i = 0; i < n; i++) {
//            System.out.println("Teams 1: " + a[i] + " " + sc[i] + " " + t[i] + " " + tt[i]);
//        }
    }

    public static int ind(String t, String a[]) { // Returns index of team t in a
        for (int i = 0; i < a.length; i++) {
            if (a[i].equals(t)) {
                return i;
            }
        }
        return -1;
    }

    public static int se(int t[], int tt) { // Searches through t for tt
        for (int i = 0; i < t.length; i++) {
            if (t[i] == tt) {
                return i;
            }
        }
        return -1;
    }
}
