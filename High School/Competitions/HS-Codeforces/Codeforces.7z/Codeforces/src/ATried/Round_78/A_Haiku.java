package ATried.Round_78;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_Haiku {

    /**
     *
     * Use a split or something like that Tags: Implementation, Strings
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
//        String s1 = scan.nextLine();
//        String s2 = scan.nextLine();
//        String s3 = scan.nextLine();
//        String s1[] = scan.nextLine().split("\\s+");
//        String s2[] = scan.nextLine().split("\\s+");
//        String s3[] = scan.nextLine().split("\\s+");
        /*
         boolean ans = true;
         String s1 = scan.nextLine();
         char ch1[] = s1.replaceAll(" ", "").toCharArray();
         int sum = 0;
         for (int i = 0; i < ch1.length; i++) {
         if (ch1[i] == 'a') {
         sum++;
         } else if (ch1[i] == 'e') {
         sum++;
         } else if (ch1[i] == 'i') {
         sum++;
         } else if (ch1[i] == 'o') {
         sum++;
         } else if (ch1[i] == 'u') {
         sum++;
         }
         }
         if (sum == 5) {
         String s2 = scan.nextLine();
         char ch2[] = s2.replaceAll(" ", "").toCharArray();
         sum = 0;
         for (int i = 0; i < ch2.length; i++) {
         if (ch2[i] == 'a') {
         sum++;
         } else if (ch2[i] == 'e') {
         sum++;
         } else if (ch2[i] == 'i') {
         sum++;
         } else if (ch2[i] == 'o') {
         sum++;
         } else if (ch2[i] == 'u') {
         sum++;
         }
         }
         if (sum == 7) {
         String s3 = scan.nextLine();
         char ch3[] = s3.replaceAll(" ", "").toCharArray();
         sum = 0;
         for (int i = 0; i < ch3.length; i++) {
         if (ch3[i] == 'a') {
         sum++;
         } else if (ch3[i] == 'e') {
         sum++;
         } else if (ch3[i] == 'i') {
         sum++;
         } else if (ch3[i] == 'o') {
         sum++;
         } else if (ch3[i] == 'u') {
         sum++;
         }
         }
         } else {
         ans = false;
         }
         out.println(sum);
         } else {
         ans = false;
         }
         out.println((ans) ? "YES" : "NO");
         //        int asw = s1.length + s2.length + s3.length;
         //        out.println(s1.length + "\n" + s2.length + "\n" + s3.length + "\n" + asw);
         */
        String s1 = scan.nextLine();
        String y1[] = s1.replaceAll("\\s+", "").split("[aeiou]");
        int con = 0;
        out.println(y1.length);
        String s2 = scan.nextLine();
        String y2[] = s2.replaceAll("\\s+", "").split("[aeiou]");
        out.println(y2.length);
        String s3 = scan.nextLine();
        String y3[] = s3.replaceAll("\\s+", "").split("[aeiou]");
        out.println(y3.length);
    }
}
