package ATried.Round_78;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_EasterEggs {

    /**
     * Tags: Constructive Algorithms, Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int a = scan.nextInt();
    }
}
