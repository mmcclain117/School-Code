package ATried.Round_78;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class D_ArchersShot {

    /**
     * Tags: Search, Geometry, Math, Pointers,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
