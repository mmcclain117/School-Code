package ATried.Round_26;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_Parquet {

    /**
     * Tags: Combinatorics, Constructive Algorithms
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Living room Length
        int m = scan.nextInt(); // Living room Width
        int a = scan.nextInt(); // Amount of planks
        int b = scan.nextInt(); // Amount of planks
        int c = scan.nextInt(); // Amount of planks
    }
}
