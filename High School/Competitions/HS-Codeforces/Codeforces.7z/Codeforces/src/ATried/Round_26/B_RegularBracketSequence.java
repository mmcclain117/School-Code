package ATried.Round_26;

import java.util.Arrays;
import java.util.Scanner;
import java.util.function.Predicate;
import java.util.regex.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class B_RegularBracketSequence {

    /**
     * Tags: Greedy
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        String a = scan.nextLine();
        /*
         String pat = "(.*)(\\d+)(.*)";
         Pattern p = Pattern.compile(pat);
         Matcher m = p.matcher(a);
         if (m.find()) {
         System.out.println("Found " + m.group(0));
         System.out.println("Found " + m.group(1));
         }
         String te = "";
         char ch[] = a.toCharArray();
         for (int i = 0; i < ch.length; i++) {
         if (ch[i] == '(') {
         te += "1";
         } else {
         te += "0";
         }
         }
         //        String patt = "(^...)"; // Returns 1
         //        String patt = "^(^...)"; // Returns 1
         //        String patt = "(...)"; // Returns 1
         String patt = "()"; // Returns 1
         String b[] = a.replaceAll("()", "B").split("[B]+");
         String c = a.replaceAll("[()]", "A");
         String bc[] = c.split("[A]+");
         //        String bt[] = te.split("[10]+"); // Empty
         String bt[] = te.split("(10)"); // Works
         //        String bt[] = te.replaceAll("10", "2").split("[2]");
         Pattern pn = Pattern.compile(patt);
         Matcher ma = pn.matcher(a);
         System.out.println(ma.groupCount());
         Predicate<String> pr = new Predicate() {

         @Override
         public boolean test(Object t) {
         return patt.contains(pn.toString());
         }
         };
         Predicate<String> pre = pn.asPredicate();
         //        System.out.println(pre.test("()"));
         //        System.out.println(pre.test("()"));
         //        System.out.println(pre.test("()"));
         Matcher mm = pn.matcher(pat);
         Matcher mc = pn.matcher(c);
         while (mc.find()) {
         System.out.println("SS");
         }
         if (ma.find()) {
         //            System.out.println(ma.find());
         System.out.println("Found " + ma.group(0));
         //            System.out.println("Found " + m.group(1));
         }
         if (mc.find()) {
         System.out.println("Found " + mc.group(0));
         //            System.out.println("Found " + m.group(1));
         }
         String ne = "";
         for (int i = 0; i < bt.length; i++) {
         //            System.out.println(b[i]);
         //            System.out.println(bc[i]);
         //            ne += bt[i];
         ne += bt[i] + "2";
         System.out.println(bt[i]);
         }
         System.out.println(ne);
         String be[] = ne.split("(10)");
         */
        String te = "";
        char ch[] = a.toCharArray();
        for (int i = 0; i < ch.length; i++) {
            if (ch[i] == '(') {
                te += "1";
            } else {
                te += "0";
            }
        }
//        System.out.println(te);
//        String bt[] = te.split("(10)"); // Works
//        System.out.println(Arrays.toString(bt));
        int sum = 0;
        while (te.contains("10")) {
            te = te.replaceFirst("10", "");
            sum++;
        }
        System.out.println(sum * 2);
    }
}
