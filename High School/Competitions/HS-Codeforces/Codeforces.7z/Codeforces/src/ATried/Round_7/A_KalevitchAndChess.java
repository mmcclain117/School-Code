package ATried.Round_7;

import static java.lang.System.out;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

public class A_KalevitchAndChess {

    /**
     * Tags: Brute Force, Constructive Algorithms
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        char grid[][] = new char[8][8];
        ArrayList<Integer> x = new ArrayList();
        ArrayList<Integer> y = new ArrayList();
        HashSet<Integer> hx = new HashSet();
        HashSet<Integer> hy = new HashSet();
        for (int i = 0; i < 8; i++) {
            String a = scan.nextLine();
            char ch[] = a.toCharArray();
            for (int ii = 0; ii < ch.length; ii++) {
                grid[i][ii] = ch[ii];
                if (ch[ii] == 'B') {
                    y.add(i);
                    x.add(ii);
                    hy.add(i);
                    hx.add(ii);
                }
            }
        }
        out.println("X HashSet:\t" + Arrays.toString(hx.toArray()));
        out.println("Y HashSet:\t" + Arrays.toString(hy.toArray()));
        out.println("X ArrayList:\t" + Arrays.toString(x.toArray()));
        out.println("Y ArrayList:\t" + Arrays.toString(y.toArray()));
    }
}
