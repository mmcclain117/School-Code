package ATried.Round_91;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_NewspaperHeadline {

    /**
     * Tags: Greedy, Strings
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        String a = scan.nextLine();
        String b = scan.nextLine();
    }
}
