package ATried.Round_91;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_Queue {

    /**
     * Tags: Search, Structures,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
