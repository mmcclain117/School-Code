package ATried.Round_82;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_Sets {

    /**
     * Tags: Constructive Algorithms, Hashing, Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Number of sets at disposal
        int line = (n * (n - 1)) / 2;
        for (int i = 0; i < line; i++) {

        }
    }
}
