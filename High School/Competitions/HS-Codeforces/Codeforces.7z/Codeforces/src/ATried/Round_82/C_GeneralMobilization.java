package ATried.Round_82;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_GeneralMobilization {

    /**
     * Tags: Structures, Similar, Sortings,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
