package ATried.Round_82;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_DoubleCola {

    /**
     * Tags: Implementation, Math
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        String name[] = {"Sheldon", "Leonard", "Penny", "Rajesh", "Howard"};
        int n = scan.nextInt();

    }
}
