package ATried.Round_131;

import static java.lang.Math.abs;
import static java.lang.System.out;
import java.util.Scanner;
import java.util.Arrays;

public class B_OppositesAttract {

    /**
     * Tags: Implementation, Math
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int t[] = new int[21];
        /*
         int t[] = new int[n];
         for (int i = 0; i < n; i++) {
         t[i] = scan.nextInt();
         }
         int con = 0;
         int cos = 0;
         Arrays.sort(t);
         for (int i = 0; i < t.length; i++) {
         //            int si = t[i];
         for (int ii = t.length - 1; ii > i; ii--) {
         if (t[i] == (t[ii] * -1)) {
         con++;
         cos++;
         //                } else {
         //                    break;
         }
         }
         if (i < t.length - 1) {
         if (t[i] == t[i + 1]) {
         cos--;
         if (cos > 0) {
         con += cos;
         }
         i++;
         }
         }
         //            out.println(con + " " + t[i] + " " + i + " " + cos);
         cos = 0;
         //            while (i < t.length - 1) {
         //                if (t[i] == t[i + 1]) {
         ////                    cos--;
         //                    con += cos;
         //                    cos--;
         //                    i++;
         //                } else {
         //                    con= 0;
         //                    break;
         //                }
         //            }
         //            cos = 0;
         //            out.println(cos + " " + i + " "+ t[i]);
         }
         */
        if (n == 1) {
            out.println("0");
        } else {
            for (int i = 0; i < n; i++) {
                int te = scan.nextInt();
                if (te <= 0) {
                    t[abs(te)]++;
                } else {
                    t[te + 10]++;
                }
            }
            int con = 0;
            for (int i = 1; i < 10; i++) {
                if (t[i] != 0 && t[i + 10] != 0) {
                    double p = Math.ceil(((double) (t[i] + t[i + 10]) / 2));
                    con += Math.ceil(p);
//                    con += (int) Math.ceil(((t[i] + t[i + 10]) / 2));
//                    out.println(con);
//                con += (int)((t[i] + t[i + 10]) / 2);
                }
            }
            int sp = t[0];
            int sum = 0;
            for (int i = 0; i < sp; i++) {
                sum += i;
            }
//            out.println(sum);
            con += sum;
//            con += (int) Math.ceil((t[0] / 2));
//            out.println(t[0]);
//            out.println(t[10] / 2);
            out.println(con);
        }
    }
}
