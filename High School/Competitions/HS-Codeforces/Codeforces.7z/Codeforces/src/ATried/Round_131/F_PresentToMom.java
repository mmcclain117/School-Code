package ATried.Round_131;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class F_PresentToMom {

    /**
     * Tags: Search, Pointers,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
