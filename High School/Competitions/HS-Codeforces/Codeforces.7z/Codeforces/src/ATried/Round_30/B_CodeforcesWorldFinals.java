package ATried.Round_30;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_CodeforcesWorldFinals {

    /**
     * Need to rearrange, Change to Implement a method Tags: Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        String a = scan.nextLine();
        String b = scan.nextLine();
        scan.close();
//        Scanner in = new Scanner(a);
//        Scanner it = new Scanner(b);
//        int dd = in.nextInt();
//        int mm = in.nextInt();
//        int yy = in.nextInt();
        int dd = Integer.parseInt(a.substring(0, 2)); // Date 
        int mm = Integer.parseInt(a.substring(3, 5)); // Month
        int yy = Integer.parseInt(a.substring(6, 8)); // Year
//        in.close();
//        int bd = it.nextInt();
//        int bm = it.nextInt();
//        int by = it.nextInt();
        int bd = Integer.parseInt(b.substring(0, 2)); // Day Born
        int bm = Integer.parseInt(b.substring(3, 5)); // Month Bord
        int by = Integer.parseInt(b.substring(6, 8)); // Year Born
//        System.out.println(dd + " " + mm + " " + yy);
        boolean cont = true; // Continue
        /* Checks Year */
        if (by + 18 <= yy) {
            System.out.println("YES");
            cont = false;
        } else if (by + 17 == yy) {
            /* Check Month */
            if (bm < mm) {
                System.out.println("YES");
                cont = false;
            } else if (bm == mm) {
                if (bd < dd || bd == dd) {
                    System.out.println("YES");
                    cont = false;
                } else {
                    System.out.println("NO");
                    cont = false;
                }
                /* Checks Day */
            } else {
                System.out.println("NO");
                cont = false;
            }
        } else {
            System.out.println("NO");
            cont = false;
        }
//        it.close();
    }
}
