package ATried.Round_30;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_Accounting {

    /**
     * Tags: Brute Force, Math,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
