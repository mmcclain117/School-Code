package ATried.Round_97;

import java.util.Scanner;

public class B_Superset {

    /**
     * Tags: Constructive Algorithms, Divide and Conquer
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int x[] = new int[n];
        int y[] = new int[n];
        for (int i = 0; i < n; i++) {
            x[i] = scan.nextInt();
            y[i] = scan.nextInt();
        }
    }
}
