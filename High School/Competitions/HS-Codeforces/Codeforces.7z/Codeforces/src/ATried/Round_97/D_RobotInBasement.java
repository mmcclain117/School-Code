package ATried.Round_97;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class D_RobotInBasement {

    /**
     * Tags: Bitmasks, Force, Implementation,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
