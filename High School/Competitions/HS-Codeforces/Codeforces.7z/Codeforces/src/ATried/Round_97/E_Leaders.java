package ATried.Round_97;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class E_Leaders {

    /**
     * Tags: Similar, Dsu, Graphs, Trees,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
