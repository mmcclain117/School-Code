package ATried.Round_9;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class E_InterestingGraphAndApples {

    /**
     * Tags: Similar, Dsu, Graphs,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
