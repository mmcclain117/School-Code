package ATried.Round_70;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_TextMessaging {

    /**
     * Tags: Expression Parsing, Greedy, Strings
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Size of one message
        String a = scan.nextLine();

    }
}
