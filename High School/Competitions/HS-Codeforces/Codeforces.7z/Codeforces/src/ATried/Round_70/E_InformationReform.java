package ATried.Round_70;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class E_InformationReform {

    /**
     * Tags: Dp, Implementation, Trees,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
