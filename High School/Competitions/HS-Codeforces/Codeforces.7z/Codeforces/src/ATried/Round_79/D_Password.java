package ATried.Round_79;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class D_Password {

    /**
     * Tags: Bitmasks, Dynamic Programming (Dp), Shortest Paths
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int k = scan.nextInt();
        int l = scan.nextInt();
    }
}
