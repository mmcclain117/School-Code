package ATried.Round_79;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_Beaver {

    /**
     * Tags: Data Structures, Dynamic Programming (Dp), Greedy, Hashing,
     * Strings, Two Pointers
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        String s = scan.nextLine();
        int n = scan.nextInt();
        for (int i = 0; i < n; i++) {
        }
    }
}
