package ATried.Round_79;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_BusGame {

    /**
     * Tags: Greedy Problems with the order need to work on if else statements
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int x = scan.nextInt();
        int y = scan.nextInt();
        boolean per = false; // If it is Ceils turn
        while (true) {
            if (x <= 1 && y <= 1) {
                break;
            } else {
                if ((x * 100 + y * 10) >= 220 && x >= 2 && y >= 2) {
                    if (per) {
                        x--;
                        if (y >= 12) {
                            y -= 12;
                            per = !per;
                        } else {
                            if (x >= 1 && y >= 2) {
                                x--;
                                y -= 2;
                                per = !per;
                            } else {
                                break;
                            }
                        }
                    } else {
                        y -= 2;
                        if (x >= 2) {
                            x -= 2;
                            per = !per;
                        } else {
                            x -= 1;
                            if (y >= 10) {
                                y -= 10;
                                out.println();
                                per = !per;
                            } else {
                                break;
                            }
                        }
                    }
                } else {
                    break;
                }
            }
        }
        String fin = per ? "Ciel" : "Hanako";
        out.println(fin);

    }
}
