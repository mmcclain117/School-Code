package ATried.Round_79;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class E_SecuritySystem {

    /**
     * Tags: Math,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
