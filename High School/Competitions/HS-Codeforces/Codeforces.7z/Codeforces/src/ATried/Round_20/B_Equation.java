package ATried.Round_20;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;
import static java.lang.Double.NaN;
import java.util.Arrays;
import java.util.HashSet;

public class B_Equation {

    /**
     * Tags: Math
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int a = scan.nextInt();
        int b = scan.nextInt();
        int c = scan.nextInt();
        double discriminant = (Math.pow(b, 2.0)) - (4 * a * c);
        double d = Math.sqrt(discriminant);
        d = (b * b) - (4.0 * a * c);
        System.out.println(d);
        if (discriminant > 0.0) {
            double root1 = (-b + d) / (2.0 * a); //X= root 1, which is larger 
            double root2 = (-b - d) / (2.0 * a); //Y= root 2, which is the smaller root 
            if (root1 == root2) {
                System.out.println("1");
                System.out.printf("%.9f", root2);
                System.out.println();
            } else {
                System.out.println("2");
                if (root1 > root2) {
                    System.out.printf("%.9f", root2);
                    System.out.println();
                    System.out.printf("%.9f", root1);
                    System.out.println();
                } else {
                    System.out.printf("%.9f", root1);
                    System.out.println();
                    System.out.printf("%.9f", root2);
                    System.out.println();
                }
            }
        } else if (discriminant == 0.0) {
            double root1 = (-b + 0.0) / (2.0 * a);//repeated root
//            System.out.println(root1 + " NaN" + (root1 == NaN));
            if ("NaN".equals(root1 + "")) {
                System.out.println("-1");
            } else {
                System.out.println("1");
                System.out.printf("%.9f", root1);
                System.out.println();
            }
        } else if (discriminant < 0.0) {
            double root[] = new double[4];
//            double root1 = -b / (2 * a);
            root[0] = -b / (2 * a);
//            double root2 = (Math.sqrt(-c)) / (2 * a);
            root[1] = (Math.sqrt(-c)) / (2 * a);
//            double root3 = -b / (2 * a);
            root[2] = -b / (2 * a);
//            double root4 = (-(Math.sqrt(-c))) / (2 * a);
            root[3] = (-(Math.sqrt(-c))) / (2 * a);
            Arrays.sort(root);
            HashSet<Double> hs = new HashSet();
            for (int i = 0; i < root.length; i++) {
                hs.add(root[i]);
            }
            hs.remove(0.0);
            hs.remove(NaN);
            System.out.println(hs.size());
            Object roots[] = hs.toArray();
//            for (double r : root) {
            for (int i = 0; i < hs.size(); i++) {
                System.out.printf("%.9f", ((double) roots[i]));
                System.out.println();
            }
        }
    }
}
