package ATried.Round_20;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_Dijkstra {

    /**
     * Tags: Graphs, Shortest Paths
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Verticies
        int m = scan.nextInt(); // Edges
        int a[] = new int[m]; // Edge endpoints
        int b[] = new int[m]; // Edge endpoints
        int w[] = new int[m]; // Length of the edge
        for (int i = 0; i < m; i++) {
            a[i] = scan.nextInt();
            b[i] = scan.nextInt();
            w[i] = scan.nextInt();
        }
    }
}
