package ATried.Round_40;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_FindColor {

    /**
     * Tags: Constructive Algorithms, Implementation, Math
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int x = scan.nextInt();
        int y = scan.nextInt();
        boolean q1 = x > 0 && y > 0; // Top Right
        boolean q2 = x < 0 && y > 0; // Top Left
        boolean q3 = x < 0 && y < 0; // Bottom Left
        boolean q4 = x > 0 && y < 0; // Bottom Right
        boolean t = x % 2 == 0; // If it is even
        if (q1 || q3) {
            if (t) { // It is black
                System.out.println("black");
            } else {
                System.out.println("white");
            }
        } else if (q2 || q4) {
            if (t) { // It is white
                System.out.println("white");
            } else {
                System.out.println("black");
            }
        }
    }
}
