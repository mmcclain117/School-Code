package ATried.Round_94;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_Friends {

    /**
     * Tags: Implementation, Math
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int m = scan.nextInt();
        int a1 = 4;
        int a2 = 4;
        int a3 = 4;
        int a4 = 4;
        int a5 = 4;
        for (int i = 0; i < m; i++) {
            int x = scan.nextInt();
            int y = scan.nextInt();
            if (x == 1 || y == 1) {
                a1--;
            }
            if (x == 2 || y == 2) {
                a2--;
            }
            if (x == 3 || y == 3) {
                a3--;
            }
            if (x == 4 || y == 4) {
                a4--;
            }
            if (x == 5 || y == 5) {
                a5--;
            }
        }
        String fin = "";
        out.println(a1 + " " + a2 + " " + a3 + " " + a4 + " " + a5);
        if (a1 <= 1 || a2 <= 1 || a3 <= 1 || a4 <= 1 || a5 <= 1) {
            if (a1 == 4 || a2 == 4 || a3 == 4 || a4 == 4 || a5 == 4) {
                fin = "FAIL";
            } else {
                fin = "WIN";
            }
        } else {
            fin = "FAIL";
        }
        out.println(fin);
    }
}
