package ATried.Round_94;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class D_EndOfExams {

    /**
     * Tags: Greedy, Math,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
