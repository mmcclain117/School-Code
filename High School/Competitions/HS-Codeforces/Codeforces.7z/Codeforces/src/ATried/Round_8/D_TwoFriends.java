package ATried.Round_8;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class D_TwoFriends {

    /**
     * Tags: Binary Search, Geometry
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int t1 = scan.nextInt();
        int t2 = scan.nextInt();
        int cx = scan.nextInt(); // Cinema X
        int cy = scan.nextInt(); // Cinema Y
        int hx = scan.nextInt(); // House X
        int hy = scan.nextInt(); // House Y
        int sx = scan.nextInt(); // Shop X
        int sy = scan.nextInt(); // Shop Y
    }
}
