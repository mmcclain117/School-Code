package ATried.Round_8;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class E_Beads {

    /**
     * Tags: Dp, Graphs,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
