package ATried.Round_8;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_ObsessionWithRobots {

    /**
     * Tags: Constructive Algorithms, Graphs, Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        String a = scan.nextLine();
        int l = 0; // Left
        int r = 0; // Right
        int u = 0; // Up
        int d = 0; // Down
        char ch[] = a.toCharArray();
        for (int i = 0; i < ch.length; i++) {
            if (ch[i] == 'L') {
                l++;
            } else if (ch[i] == 'R') {
                r++;
            } else if (ch[i] == 'U') {
                u++;
            } else if (ch[i] == 'D') {
                d++;
            }
        }
        out.println("Up: " + u + "\nDown: " + d + "\nLeft: " + l + "\nRight: " + r);
    }
}
