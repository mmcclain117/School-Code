package ATried.Round_8;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_LookingForOrder {

    /**
     * Tags: Bitmasks, Dynamice Programming (Dp)
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int x = scan.nextInt();
        int y = scan.nextInt();
        int n = scan.nextInt(); // Number of Objects
    }
}
