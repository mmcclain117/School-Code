package ATried.Round_8;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_TrainAndPeter {

    /**
     * Tags: Strings
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        String n = scan.nextLine();
        String a = scan.nextLine();
        String b = scan.nextLine();
    }
}
