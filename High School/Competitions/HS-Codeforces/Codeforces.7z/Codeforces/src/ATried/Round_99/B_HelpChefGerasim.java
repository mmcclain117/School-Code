package ATried.Round_99;

import static java.lang.System.out;
import java.util.Scanner;
import static java.lang.Math.abs;
import java.util.Arrays;

public class B_HelpChefGerasim {

    /**
     * Tags: Implementation, Sortings,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int a[] = new int[n];
        int ave = 0;
        for (int i = 0; i < n; i++) {
            a[i] = scan.nextInt();
            ave += a[i];
        }
        int b[] = a;
        out.println(Arrays.toString(b));
        ave /= n;
        Arrays.sort(a);
        int end = a[n];
        int start = a[0];
        int mid = a[n / 2];
        out.println(Arrays.toString(a));
        if (start == end) {
            out.println("Exemplary pages.");
        } else if (abs(mid - start) == abs(mid - end)) {
//            int cav = abs(mid - start);
//            int cbv = abs(mid - end);
//            out.println(cav + " "+ cbv);
            int ca = 0;
            int cb = 0;
            for (int i = 0; i < n; i++) {
                int te = b[i];
                if (te == start) {
                    cb = i + 1;
                }
                if (te == end) {
                    ca = i + 1;
                    out.println(te);
                }
            }
            out.println(((end - start) / 2) + " ml. from #" + ca + " to cup #" + cb + ".");
        } else {
            out.println("Unrecoverable configuration");
        }
    }
}
