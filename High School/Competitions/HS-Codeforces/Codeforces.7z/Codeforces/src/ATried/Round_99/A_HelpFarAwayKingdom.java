package ATried.Round_99;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_HelpFarAwayKingdom {

    /**
     * Tags: Strings
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
//        double d = scan.nextDouble();
        String n = scan.nextLine();
    }
}
