package ATried.Round_88;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_Chord {

    /**
     * Tags: Brute Force, Implementation
     *
     * @param args
     */
//    Major if X to Y is 4 semitones Y to Z is 3 semitones
//    MInor if X to Y is 3 semitones Y to Z is 4 semitones
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        String a = scan.nextLine();
        String b[] = a.split("\\s+");
        String notes[] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "B", "H"};
        int x = 0;
        int y = 0;
        int z = 0;
        boolean contin = true; // Continue
        if (comp(b, notes) == 7) {
            for (int i = 0; i < notes.length; i++) {
                if (b[0].equals(notes[i])) {
                    x = i;
                }
                if (b[1].equals(notes[i])) {
                    y = i;
                }
                if (b[2].equals(notes[i])) {
                    z = i;
                }
            }
            if (y - x == 3) {
                if (z - y == 4) {
                    System.out.println("minor");
                    contin = false;
                }
            } else if (y - x == 4) {
                if (z - y == 3) {
                    System.out.println("major");
                    contin = false;
                }
            }
        }
        if (contin) {
            String s[] = new String[3]; // Set 1
            s[0] = b[0];
            s[1] = b[2];
            s[2] = b[1];
            if (comp(s, notes) == 7) {
                for (int i = 0; i < notes.length; i++) {
                    if (s[0].equals(notes[i])) {
                        x = i;
                    }
                    if (s[1].equals(notes[i])) {
                        y = i;
                    }
                    if (s[2].equals(notes[i])) {
                        z = i;
                    }
                }
                if (y - x == 3) {
                    if (z - y == 4) {
                        System.out.println("minor");
                        contin = false;
                    }
                } else if (y - x == 4) {
                    if (z - y == 3) {
                        System.out.println("major");
                        contin = false;
                    }
                }
            }
        }
        if (contin) {
            String s[] = new String[3]; // Set 2
            s[0] = b[1];
            s[1] = b[0];
            s[2] = b[2];
            if (comp(s, notes) == 7) {
                for (int i = 0; i < notes.length; i++) {
                    if (s[0].equals(notes[i])) {
                        x = i;
                    }
                    if (s[1].equals(notes[i])) {
                        y = i;
                    }
                    if (s[2].equals(notes[i])) {
                        z = i;
                    }
                }
                if (y - x == 3) {
                    if (z - y == 4) {
                        System.out.println("minor");
                        contin = false;
                    }
                } else if (y - x == 4) {
                    if (z - y == 3) {
                        System.out.println("major");
                        contin = false;
                    }
                }
            }
        }
        if (contin) {
            String s[] = new String[3]; // Set 3
            s[0] = b[1];
            s[1] = b[2];
            s[2] = b[0];
            if (comp(s, notes) == 7) {
                for (int i = 0; i < notes.length; i++) {
                    if (s[0].equals(notes[i])) {
                        x = i;
                    }
                    if (s[1].equals(notes[i])) {
                        y = i;
                    }
                    if (s[2].equals(notes[i])) {
                        z = i;
                    }
                }
                if (y - x == 3) {
                    if (z - y == 4) {
                        System.out.println("minor");
                        contin = false;
                    }
                } else if (y - x == 4) {
                    if (z - y == 3) {
                        System.out.println("major");
                        contin = false;
                    }
                }
            }
        }
        if (contin) {
            String s[] = new String[3]; // Set 4
            s[0] = b[2];
            s[1] = b[1];
            s[2] = b[0];
            if (comp(s, notes) == 7) {
                for (int i = 0; i < notes.length; i++) {
                    if (s[0].equals(notes[i])) {
                        x = i;
                    }
                    if (s[1].equals(notes[i])) {
                        y = i;
                    }
                    if (s[2].equals(notes[i])) {
                        z = i;
                    }
                }
                if (y - x == 3) {
                    if (z - y == 4) {
                        System.out.println("minor");
                        contin = false;
                    }
                } else if (y - x == 4) {
                    if (z - y == 3) {
                        System.out.println("major");
                        contin = false;
                    }
                }
            }
        }
        if (contin) {
            String s[] = new String[3]; // Set 5
            s[0] = b[2];
            s[1] = b[0];
            s[2] = b[1];
            if (comp(s, notes) == 7) {
                for (int i = 0; i < notes.length; i++) {
                    if (s[0].equals(notes[i])) {
                        x = i;
                    }
                    if (s[1].equals(notes[i])) {
                        y = i;
                    }
                    if (s[2].equals(notes[i])) {
                        z = i;
                    }
                }
                if (y - x == 3) {
                    if (z - y == 4) {
                        System.out.println("minor");
                        contin = false;
                    }
                } else if (y - x == 4) {
                    if (z - y == 3) {
                        System.out.println("major");
                        contin = false;
                    }
                }
            }
        }
//        [1, 2 , 3] [1, 3, 2] [2, 1, 3] [2, 3, 1] [3, 2, 1] [3, 1, 2]
        if (contin) {
            System.out.println("Strange");
        }
    }

    private static int comp(String[] b, String c[]) {
        int x = 0;
        int z = 0;
        for (int i = 0; i < c.length; i++) {
            if (c[i].equals(b[0])) {
                x = i;
            }
            if (c[i].equals(b[2])) {
                z = i;
            }
        }
        return z - x;
    }

}
