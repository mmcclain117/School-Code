package ATried.Round_88;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_Keyboard {

    /**
     * Tags: Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int m = scan.nextInt();
        int x = scan.nextInt();
        for (int i = 0; i < n; i++) {
            String cur = scan.nextLine();
            char ch[] = cur.toCharArray();
        }
        int q = scan.nextInt();
        for (int i = 0; i < q; i++) {
            String k = scan.nextLine();
        }
    }
}
