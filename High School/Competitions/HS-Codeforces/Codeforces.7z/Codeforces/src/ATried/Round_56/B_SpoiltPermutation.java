package ATried.Round_56;

import static java.lang.System.out;
import java.util.Scanner;
import java.util.Random;

public class B_SpoiltPermutation {

    /**
     * Tags: Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        Random r = new Random(1);
        Random rr = new Random(1);
        out.println(r.nextDouble() + " " + rr.nextDouble());
        int n = scan.nextInt();
        int set[] = new int[n];
        int sx = 0;
        int sy = 0;
        for (int i = 0; i < n; i++) {
            set[i] = scan.nextInt();
        }
        int las = 0;
        boolean rev = false;
        boolean res = true;
        for (int i = 0; i < n; i++) {
            if (res) {
                if (rev) {
                    if (set[i] - 1 != las) {
                        rev = false;
                        res = false;
                        sy = i;
                    } else {
                        las = set[i]; // Check
                    }
                }
            } else {
                if (set[i] + 1 != las) {
                    if (rev) {
                        res = false;
                    } else {
                        sx = i;
                        rev = true;
                    }

                    las = set[i]; // Check set
                }
                if (set[i] + 1 == las) {
                    las = set[i + 1]; // Check

                }
            }
        }
        if (res) {
            out.println("0 0");
        } else {
            out.println(sx + " " + sy);
        }
    }
}
