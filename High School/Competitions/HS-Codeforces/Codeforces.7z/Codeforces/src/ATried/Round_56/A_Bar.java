package ATried.Round_56;

import static java.lang.System.out;
import java.util.Arrays;
import java.util.Scanner;

public class A_Bar {

    /**
     * Tags: Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        scan.nextLine();
        String type[] = {"absinth", "beer", "brandy", "champagne", "gin", "rum", "sake", "tequila", "vodka", "whiskey", "wine"};
//        String type = "absinth beer brandy champagne gin rum sake tequila vodka whiskey wine";
        int con = 0;
//        scan.nextLine();
        for (int i = 0; i < n; i++) {
            String te = scan.nextLine().toLowerCase();
//            out.println(te);
            if (te.length() <= 9) {
                int u = 0;
                for (int ix = 0; ix < type.length; ix++) {
                    if (type[ix].equals(te)) {
                        u = ix;
                    }
                }
                if (u > 0) {
                    con++;
//                out.println(te);
                } else {
                    try {
                        int o = (Integer.parseInt(te));
                        if (o <= 17) {
                            con++;
                        }
                    } catch (Exception e) {
                    }
                }
            }
        }
        out.println(con);
    }
}
