package ATried.Round_56;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class E_DominoPrinciple {

    /**
     * Tags: Search, Structures, Sortings,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
