package ATried.Round_28;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_BenderProblem {

    /**
     * Not Done Tags: Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Amount of Nails
        int m = scan.nextInt(); // Amount of Rods
        int a[] = new int[n];
        for (int i = 0; i < n; i++) {
            int t = scan.nextInt();
            int te = scan.nextInt();
        }
        for (int i = 0; i < m; i++) {

        }
    }
}
