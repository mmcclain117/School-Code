package ATried.Round_28;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_PSort {

    /**
     * Tags: Similar, Dsu, Graphs
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
