package ATried.Round_28;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class D_DontFearDravDeIsKind {

    /**
     * Tags: Search, Structures, Dp, Hashing,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
