package ATried.Round_37;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_Towers {

    /**
     * Tags: Sortings
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Number of bars to dispose
        int l[] = new int[n];
        for (int i = 0; i < n; i++) {
            l[i] = scan.nextInt();
        }

    }
}
