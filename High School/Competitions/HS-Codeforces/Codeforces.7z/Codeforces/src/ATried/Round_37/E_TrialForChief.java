package ATried.Round_37;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class E_TrialForChief {

    /**
     * Tags: Graphs, Greedy, Paths,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
