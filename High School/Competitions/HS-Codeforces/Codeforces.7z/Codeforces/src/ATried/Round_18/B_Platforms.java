package ATried.Round_18;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_Platforms {

    /**
     * Tags: Force, Math,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
