package ATried.Round_14;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_YoungPhotographer {

    /**
     * Tags: Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int x0 = scan.nextInt();
        for (int i = 0; i < n; i++) {
            int a = scan.nextInt();
            int b = scan.nextInt();
        }
    }
}
