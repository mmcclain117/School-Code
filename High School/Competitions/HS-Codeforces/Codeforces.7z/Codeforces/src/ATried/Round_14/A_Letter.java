package ATried.Round_14;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_Letter {

    /**
     * Tags: Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
