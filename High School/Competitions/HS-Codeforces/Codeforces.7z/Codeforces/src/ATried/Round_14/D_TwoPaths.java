package ATried.Round_14;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class D_TwoPaths {

    /**
     * Tags: Dfs and Similar, Dynamic Programming (Dp), Graphs, Shortest Paths,
     * Trees, Two Pointers
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
    }
}
