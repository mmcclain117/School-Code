package ATried.Round_2;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;
import java.util.HashMap;

public class A_Winner {

    /**
     * Tags: Hashing, Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        HashMap<String, Integer> hm = new HashMap();
        for (int i = 0; i < n; i++) {
            String a = scan.next();
            int b = scan.nextInt();
            hm.put(a, b);
        }
        out.println(hm.toString());
    }
}
