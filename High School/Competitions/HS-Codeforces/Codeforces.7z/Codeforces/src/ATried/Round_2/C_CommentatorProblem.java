package ATried.Round_2;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_CommentatorProblem {

    /**
     * Tags: Geometry
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int x1 = scan.nextInt();
        int y1 = scan.nextInt();
        int r1 = scan.nextInt(); // Radius
        int x2 = scan.nextInt();
        int y2 = scan.nextInt();
        int r2 = scan.nextInt(); // Radius
        int x3 = scan.nextInt();
        int y3 = scan.nextInt();
        int r3 = scan.nextInt(); // Radius

    }
}
