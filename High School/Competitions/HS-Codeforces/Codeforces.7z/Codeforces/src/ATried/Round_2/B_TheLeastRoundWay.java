package ATried.Round_2;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_TheLeastRoundWay {

    /**
     * Tags: Dynamic Programming (Dp), Math
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int b[][] = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int ii = 0; ii < n; ii++) {
                b[i][ii] = scan.nextInt();
            }
        }

    }
}
