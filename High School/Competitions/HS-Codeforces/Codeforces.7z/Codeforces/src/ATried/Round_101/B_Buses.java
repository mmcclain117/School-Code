package ATried.Round_101;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_Buses {

    /**
     * Tags: Binary Search, Data Structures, Dynamic Programming (Dp)
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int m = scan.nextInt();
        int s[] = new int[m]; // Start Bus
        int t[] = new int[m]; // Stop Bus
        for (int i = 0; i < m; i++) {
            s[i] = scan.nextInt();
            t[i] = scan.nextInt();
        }
    }
}
