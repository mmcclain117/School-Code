package ATried.Round_101;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_Homework {

    /**
     * Tags: Greedy
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        String a = scan.nextLine();
        int n = a.length();
        int k = scan.nextInt(); // Charecters Deleted
//                Find the least number of distinct variables deleted
        char ch[] = a.toCharArray();

    }
}
