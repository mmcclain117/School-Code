package ATried.Round_212;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_Cowboys {

    /**
     * Tags: Dynamic Programming (Dp), Math
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        String a = scan.nextLine();
    }
}
