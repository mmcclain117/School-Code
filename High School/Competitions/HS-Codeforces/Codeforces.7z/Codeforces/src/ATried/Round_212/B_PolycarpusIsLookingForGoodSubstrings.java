package ATried.Round_212;

import static java.lang.System.out;
import java.util.Scanner;
import java.util.Arrays;

public class B_PolycarpusIsLookingForGoodSubstrings {

    /**
     * Tags: Bitmasks, Hashing, Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        String s = scan.next();
        int m = scan.nextInt();
        out.println(m);
        for (int i = 0; i < m; i++) {
            String c = scan.next();
            String[] a = s.split("[" + c + "]+");
            if (s.contains(c)) {
                out.println((a.length + 1));
            } else {
                out.println(a.length);
            }
            out.println(Arrays.toString(a));
        }
    }
}
