package ATried.Round_212;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class D_CuttingAFence {

    /**
     * Tags: Binary Search, Data Structures, Dsu
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Number of planks on fence
        int a[] = new int[n]; // Height of each plank
        for (int i = 0; i < n; i++) {
            a[i] = scan.nextInt();
        }
        int m = scan.nextInt();
        int k[] = new int[m];
        for (int i = 0; i < m; i++) {
            k[i] = scan.nextInt();
        }
    }
}
