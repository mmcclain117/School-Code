package ATried.Round_3;

import static java.lang.System.out;
import java.util.Scanner;

// Round 3
public class C_TicTacToe {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        char ch[][] = new char[3][3];
        for (int i = 0; i < 3; i++) {
            String a = scan.nextLine();
            ch[i] = a.toCharArray();
        }
        /*
         for (int y = 0; y < 3; y++) {
         for (int x = 0; x < 3; x++) {
         System.out.print(ch[y][x] + " ");
         }
         System.out.println();
         }
         */
        int coun[] = count(ch);
        String h = checkHor(ch);
        String v = checkVert(ch);
        String c = checkCross(ch);
//        out.println("Horizontal " + h);
//        out.println("Vertical " + v);
//        out.println("Crossed " + c);
        int countX = coun[0];
        int countO = coun[1];
        if ("d".equals(h) && "d".equals(v) && "d".equals(c)) {
            if (countX == 5 && countO == 4) {
                out.println("draw");
            } else if (countX < countO) {
                out.println("illegal");
            } else {
                String st = countX == countO ? "first" : "second";
                out.println(st);
            }
        } else if (!"d".equals(h) || !"d".equals(v) || !"d".equals(c)) {
            int con = 0;
            con += !"d".equals(h) ? 1 : 0;
            con += !"d".equals(v) ? 1 : 0;
            con += !"d".equals(c) ? 1 : 0;
            if (con > 1) {
                out.println("illegal");
            } else {
                String stat = !("d".equals(h)) ? h : !("d".equals(v)) ? v : !("d".equals(c)) ? c : "";
                if (stat.equals("O")) {
                    out.println("the second player won");
                } else if (stat.equals("X")) {
                    out.println("the first player won");
                } else {
                    out.println("illegal");
                }
            }
        } else if (countX < countO) {
            out.println("illegal");
        }
    }

    private static String checkHor(char ch[][]) {
        for (int i = 0; i < 3; i++) {
            if (ch[i][0] == ch[i][1] && ch[i][1] == ch[i][2]) {
                return ch[i][1] + "";
            }
        }
        return "d";
    }

    private static String checkVert(char ch[][]) {
        for (int i = 0; i < 3; i++) {
            if (ch[0][i] == ch[1][i] && ch[1][i] == ch[2][i]) {
                return ch[1][i] + "";
            }
        }
        return "d";

    }

    private static String checkCross(char ch[][]) {
        if (ch[0][0] == ch[1][1] && ch[1][1] == ch[2][2]) {
            return ch[0][0] + "";
        } else if (ch[0][2] == ch[1][1] && ch[1][1] == ch[2][0]) {
            return ch[1][1] + "";
        }
        return "d";

    }

    private static int[] count(char[][] ch) {
        int f = 0;
        int s = 0;
        int fin[] = new int[2];
        for (int y = 0; y < 3; y++) {
            for (int x = 0; x < 3; x++) {
                if (ch[y][x] == 'X') {
                    f++;
                } else if (ch[y][x] == 'O') {
                    s++;
                }
            }
        }
        fin[0] = f;
        fin[1] = s;
        return fin;
    }
}
