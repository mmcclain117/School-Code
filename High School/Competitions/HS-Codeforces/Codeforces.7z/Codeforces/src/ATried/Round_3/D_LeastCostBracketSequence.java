package ATried.Round_3;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;
import static java.lang.Math.abs;

public class D_LeastCostBracketSequence {

    /**
     * Tags: Greedy
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        String d = scan.nextLine();
        char ch[] = d.toCharArray();
        int op = 0; // Number of Open Parenthases
        int cp = 0; // Number of Closed Parenthases
        int qu = 0; // Number of Question Marks
        for (int i = 0; i < ch.length; i++) {
            if (ch[i] == ')') {
                cp++;
            } else if (ch[i] == '(') {
                op++;
            } else {
                qu++;
            }
        }
        int a[] = new int[qu];
        int b[] = new int[qu];
        for (int i = 0; i < qu; i++) {
            a[i] = scan.nextInt();
            b[i] = scan.nextInt();
        }

        if (abs(op - cp) < qu) {
            int les = Integer.MAX_VALUE;
            for (int i = 0; i < qu; i++) {
                int sum = 0;
            }
        } else {
            out.println("0 1 this is screwing my program up");
        }
    }
}
