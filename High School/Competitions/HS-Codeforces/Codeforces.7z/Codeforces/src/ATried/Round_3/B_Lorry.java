package ATried.Round_3;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_Lorry {

    /**
     * Tags: Greedy, Sortings
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Number of waterborne vehicles
        int v = scan.nextInt(); // Truck body Volume
        int t[] = new int[n]; // Vehicle type
        int p[] = new int[n]; // Carrying capacity
        int mc = 0; // Max Carrying capacity
        int mp = 0; // Max Number of Vehicles
        for (int i = 0; i < n; i++) {
            t[i] = scan.nextInt();
            p[i] = scan.nextInt();
        }

    }
}
