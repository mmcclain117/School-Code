package ATried.Round_69;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_Bets {

    /**
     * Tags: Greedy, Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int x = scan.nextInt();
        int y = scan.nextInt();
        int n = scan.nextInt();
        int d = scan.nextInt();

    }
}
