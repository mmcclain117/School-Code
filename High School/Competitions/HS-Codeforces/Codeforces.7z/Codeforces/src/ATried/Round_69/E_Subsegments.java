package ATried.Round_69;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class E_Subsegments {

    /**
     * Tags: Structures, Implementation,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
