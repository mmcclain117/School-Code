package ATried.Round_98;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class E_HelpShrekAndDonkey {

    /**
     * Tags: Dynamic Programming (Dp), Games, Math, Probabilities
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int m = scan.nextInt(); // Shreks Cards
        int n = scan.nextInt(); // Donkeys Cards
        if (m == 0) {
            double mo = (1 / (double) (1 + n)); // Shreks odds
            double no = 1 - mo; // Donkeys odds
            out.println(mo + " " + no);
        } else if (n == 0) {
            out.println("1 0");
        } else if (m == n) {
            out.println("0.5 0.5");
        } else {
            out.println("Shit");
        }
    }
}
