package ATried.Round_22;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_BargainingTable {

    /**
     * Tags: Brute Force, Dynamic Programming (Dp)
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int m = scan.nextInt();
        for (int i = 0; i < n; i++) {
            String a = scan.nextLine();
            char ch[] = a.toCharArray();
            for (int ii = 0; ii < ch.length; ii++) {

            }
        }
    }
}
