package ATried.Round_22;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_SystemAdministrator {

    /**
     * Tags: Graphs
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int m = scan.nextInt();
        int v = scan.nextInt();
        if (n * 2 < m) {
            System.out.println("-1");
        } else {

        }
    }
}
