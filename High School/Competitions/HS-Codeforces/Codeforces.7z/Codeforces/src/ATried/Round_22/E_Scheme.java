package ATried.Round_22;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class E_Scheme {

    /**
     * Tags: Dfs and Similar, Graphs, Trees
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Amount of members
        for (int i = 0; i < n; i++) {
            int fi = scan.nextInt(); // Index of person
        }
    }
}
