package ATried.Round_23;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class D_Tetragon {

    /**
     * Tags: Geometry, Math
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int t = scan.nextInt();
        for (int i = 0; i < t; i++) {
            int x1 = scan.nextInt();
            int y1 = scan.nextInt();
            int x2 = scan.nextInt();
            int y2 = scan.nextInt();
            int x3 = scan.nextInt();
            int y3 = scan.nextInt();

        }
    }
}
