package ATried.Round_23;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_OrangesAndApples {

    /**
     * Tags: Constructive Algorithms, Sortings
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int t = scan.nextInt(); // Number of test cases
        for (int i = 0; i < t; i++) {
            int n = scan.nextInt();
            int a[] = new int[2 * n - 1]; // Apples
            int o[] = new int[2 * n - 1]; // Oranges
            for (int ii = 0; ii < (n * 2) - 1; ii++) {
                a[ii] = scan.nextInt();
                o[ii] = scan.nextInt();
            }
        }
    }
}
