package ATried.Round_23;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class E_Tree {

    /**
     * Tags: Dynamic Programming (DP)
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int a[] = new int[n - 1];
        int b[] = new int[n - 1];
        for (int i = 0; i < n - 1; i++) {
            a[i] = scan.nextInt();
            b[i] = scan.nextInt();
        }
    }
}
