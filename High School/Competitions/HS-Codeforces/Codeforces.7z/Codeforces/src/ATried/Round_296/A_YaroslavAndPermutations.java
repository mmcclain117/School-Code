package ATried.Round_296;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_YaroslavAndPermutations {

    /**
     * Tags: Greedy, Math
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int a[] = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = scan.nextInt();
        }
    }
}
