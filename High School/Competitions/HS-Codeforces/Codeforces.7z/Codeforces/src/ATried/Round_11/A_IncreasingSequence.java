package ATried.Round_11;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_IncreasingSequence {

    /**
     * Tags: Constructive Algorithms, Implementation, Math
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int d = scan.nextInt();
        int con = 0;
        int las = 0;
        for (int i = 0; i < n; i++) {
            int cur = scan.nextInt();
            if (cur > las) {
                las = cur;
            } else {
                if ((las - cur) % d == 0) {
                    con += (las - cur) / d;
                    las = cur + (las - cur);
                } else {
                    con += ((las - cur) / d) + 1;
                    las = cur + (las - cur) + ((las - cur) % d);
                }
            }
            out.println(cur + " " + las + " " + con);
        }
        out.println(con);
    }
}
