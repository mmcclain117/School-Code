package ATried.Round_11;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_JumpingJack {

    /**
     * Tags: Math
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int goal = scan.nextInt();
        int con = 0;
        while (goal != con) {
            if (goal > con) {
                goal -= con;
                con++;
            } else if (goal < con) {
                goal += con;
                con++;
            } else if (con == 44723) {
                System.out.println(goal);
                break;
            }
        }
        System.out.println(con);
    }
}
