package ATried.Round_11;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class D_ASimpleTask {

    /**
     * Tags: Bitmasks, Dp, Graphs,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
