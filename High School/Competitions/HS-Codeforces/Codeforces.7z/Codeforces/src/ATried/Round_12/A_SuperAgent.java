package ATried.Round_12;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_SuperAgent {

    /**
     * Tags: Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        char ch[][] = new char[3][3];
        for (int i = 0; i < 3; i++) {
            String a = scan.nextLine();
            char c[] = a.toCharArray();
            for (int ii = 0; ii < 3; ii++) {
                ch[i][ii] = c[ii];
            }

        }
    }
}
