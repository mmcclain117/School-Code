package ATried.Round_38;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_Blinds {

    /**
     * Tags: Brute Force
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int l = scan.nextInt();
    }
}
