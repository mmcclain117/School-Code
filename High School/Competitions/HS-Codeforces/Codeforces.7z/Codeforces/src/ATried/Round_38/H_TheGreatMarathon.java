package ATried.Round_38;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class H_TheGreatMarathon {

    /**
     * Tags: Dp,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
