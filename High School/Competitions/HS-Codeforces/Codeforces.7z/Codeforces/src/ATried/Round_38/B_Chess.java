package ATried.Round_38;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;
import java.util.Arrays;

public class B_Chess {

    /**
     * Not Done Tags: Brute Force, Implementation, Math
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        String r = scan.nextLine(); // Place of the Rook
        String k = scan.nextLine(); // Place of the Knight
        boolean board[][] = new boolean[8][8];
        int rx = r.charAt(0) - 97;
        int ry = Integer.parseInt(r.charAt(1) + "");
        int kx = k.charAt(0) - 97;
        int ky = Integer.parseInt((k.charAt(1)) + "");
        ry--;
        ky--;
        Arrays.fill(board[ry], true);
//        board[ky][kx] = true;
        for (int i = 0; i < 8; i++) {
            board[i][rx] = true;
        }
        if (ky + 2 < 8) { // Down 2
            if (kx - 1 >= 0) { // Left 1
                board[ky + 2][kx - 1] = true;
            }
            if (kx + 1 < 8) { // Right 1
                board[ky + 2][kx + 1] = true;
            }
        }
        if (ky - 2 >= 0) { // Up 2
            if (kx - 1 >= 0) { // Left 1
                board[ky + 2][kx - 1] = true;
            }
            if (kx + 1 < 8) { // Right 1
                board[ky + 2][kx + 1] = true;
            }
        }

        if (ky + 1 < 8) { // Down 1
            if (kx - 2 >= 0) { // Left 2
                board[ky + 1][kx - 2] = true;
            }
            if (kx + 2 < 8) { // Right 2
                board[ky + 1][kx + 2] = true;
            }
        }
        if (ky - 1 >= 0) { // Up 1
            if (kx - 2 >= 0) { // Left 2
                board[ky + 1][kx - 2] = true;
            }
            if (kx + 2 < 8) { // Right 2
                board[ky + 1][kx + 2] = true;
            }
        }
        int sum = 0;
        for (int y = 0; y < 8; y++) {
            for (int x = 0; x < 8; x++) {
                sum += board[y][x] ? 1 : 0;
                System.out.print(board[y][x] + " ");
            }
            System.out.println();
        }
        System.out.println("Sum: " + sum);
        System.out.println("Left: " + (64 - sum));
    }
}
