package ATried.Round_85;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_Domino {

    /**
     * Tags: Constructive Algorithms, Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
    }
}
