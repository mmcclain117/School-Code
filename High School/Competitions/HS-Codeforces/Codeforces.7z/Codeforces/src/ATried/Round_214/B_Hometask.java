package ATried.Round_214;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;
import java.util.Arrays;

public class B_Hometask {

    /**
     * Tags: Brute Force, Constructive Algorithms, Greedy, Math
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int a[] = new int[n];
        int a2 = 0;
        int a3 = 0;
        int a5 = 0;
        int sum = 0;
        for (int i = 0; i < n; i++) {
            a[i] = scan.nextInt();
            sum += a[i];
            if (a[i] == 2) {
                a2++;
            } else if (a[i] == 3) {
                a3++;
            } else if (a[i] == 5) {
                a5++;
            }
        }
        if (n == 1) {
            String fin = a[0] % 3 == 0 && a[0] % 2 == 0 && a[0] % 5 == 0 ? a[0] + "" : -1 + "";
            out.println(fin);
        } else {
            Arrays.sort(a); // Accending orders
            out.println(Arrays.toString(a));
        }
    }
}
