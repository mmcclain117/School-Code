package ATried.Round_17;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class D_Notepad {

    /**
     * Tags: Theory,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
