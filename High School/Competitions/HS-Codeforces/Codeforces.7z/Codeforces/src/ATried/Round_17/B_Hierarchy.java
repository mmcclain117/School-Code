package ATried.Round_17;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_Hierarchy {

    /**
     * Tags: Similar, Dsu, Greedy, Paths,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
