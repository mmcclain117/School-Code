package ATried.Round_39;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;
import static java.lang.System.in;

public class D_CubicalPlanet {

    /**
     * Tags: Math
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(in);
        int x1 = scan.nextInt();
        int y1 = scan.nextInt();
        int z1 = scan.nextInt();
        int x2 = scan.nextInt();
        int y2 = scan.nextInt();
        int z2 = scan.nextInt();
        boolean x = x1 == x2;
        boolean y = y1 == y2;
        boolean z = z1 == z2;
        if (x && y || x && z || y && z) {
            out.println("YES");
        } else {
            out.println("NO");
        }
    }
}
