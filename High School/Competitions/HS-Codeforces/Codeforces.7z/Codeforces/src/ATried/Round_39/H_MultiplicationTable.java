package ATried.Round_39;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;
import static java.lang.System.in;

public class H_MultiplicationTable {

    /**
     * Tags: Implementation,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(in);

    }
}
