package ATried.Round_39;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;
import static java.lang.System.in;

public class E_WhatHasDirichletGotToDoWithThat {

    /**
     * Tags: Dynamic Programming (Dp), Games
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(in);
        int a = scan.nextInt(); // Number of Boxes
        int b = scan.nextInt(); // Number of items
        int n = scan.nextInt(); // Number of ways
    }
}
