package ATried.Round_39;

import static java.lang.System.in;
import static java.lang.System.out;
import java.util.Scanner;
import java.util.ArrayList;

public class B_CompanyIncomeGrowth {

    /**
     * Tags: Greedy
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(in);
        int n = scan.nextInt();
//        int a[] = new int[n];
        int con = 0;
        ArrayList<Integer> years = new ArrayList();
        for (int i = 0; i < n; i++) {
//            a[i] = scan.nextInt();
//            System.out.println(i + " " + a[i]);
            int t = scan.nextInt();
            if (t == con) {
                years.add((2001 + i));
                con++;
            }
        }
        out.println(years.size());
        for (Integer year : years) {
            out.print(year + " ");
        }
    }
}
