package ATried.Round_39;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;
import static java.lang.System.in;

public class A_CCalculations {

    /**
     * Tags: Expression Parsing, Greedy
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(in);
        int a = scan.nextInt();
        String b = scan.nextLine();
//        Increment a as mich as possible
//        Then multiple and substirute
//        If any left add more and print out

    }
}
