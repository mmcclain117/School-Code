package ATried.Round_27;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class E_NumberWithTheGivenAmountOfDivisors {

    /**
     * Tags: Force, Dp, Theory,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
