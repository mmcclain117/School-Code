package ATried.Round_609;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;
import java.util.Arrays;

public class B_TheBestGift {

    /**
     * Tags: Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int m = scan.nextInt();
        int a[] = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = scan.nextInt();
        }
        Arrays.sort(a);
//        int sum = 0;
//        for (int i = 0; i < n; i++) {
//            sum += i;
//        }
//        out.println(sum);
        long b = System.nanoTime();
        int con = 0;
        for (int i = 0; i < n - 1; i++) {
            if (a[i] == m) {
                break;
            }
            for (int ii = i + 1; ii < n; ii++) {
                con += a[i] == a[ii] ? 0 : 1;
            }
        }
        out.println(con);
        out.println(System.nanoTime() - b);
    }
}
