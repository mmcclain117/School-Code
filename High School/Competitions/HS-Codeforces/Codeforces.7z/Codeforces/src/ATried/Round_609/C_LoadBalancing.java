package ATried.Round_609;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_LoadBalancing {

    /**
     * Tags: Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Number of servers
        int m[] = new int[n];
        for (int i = 0; i < n; i++) {
            m[i] = scan.nextInt();
        }
    }
}
