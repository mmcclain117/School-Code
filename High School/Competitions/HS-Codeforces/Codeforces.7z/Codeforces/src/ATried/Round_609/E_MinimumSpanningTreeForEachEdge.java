package ATried.Round_609;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class E_MinimumSpanningTreeForEachEdge {

    /**
     * Tags: Structures, Similar, Dsu, Graphs, Trees,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
