package ATried.Round_31;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

public class B_SysadminBob {

    /**
     * Tags: Strings
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        String a = scan.nextLine();
        char ch[] = a.toCharArray();
        ArrayList<String> ar = new ArrayList();
        int con = 0;
//        System.out.println(ch.length);
        if (ch[0] == '@' || ch.length <= 2 || a.contains("@@")) {
            System.out.println("No Solution");
        } else {
            String temp = "";
            boolean work = true;
            while (con < ch.length && work) {
                if (ch[con] == '@' && con + 1 < ch.length) {
                    temp += ch[con];
                    ar.add(temp);
                    temp = "";
                } else if (con + 1 > ch.length) {
                    work = false;
                } else {
                    temp += ch[con];
                }
                con++;
            }
//            if (work) {
            System.out.println(Arrays.toString(ar.toArray()));
//            } else {
            System.out.println("No solution");
//            }
        }
    }
}
