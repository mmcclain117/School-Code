package ATried.Round_80;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class D_FallingAnvils {

    /**
     * Tags: Geometry, Probabilities
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Number of test cases
        for (int j = 0; j < n; j++) {
            int a = scan.nextInt();
            int b = scan.nextInt();
//            X^2 +sqrt(p [0 ,a]) * X + Q[-b, b]
        }
    }
}
