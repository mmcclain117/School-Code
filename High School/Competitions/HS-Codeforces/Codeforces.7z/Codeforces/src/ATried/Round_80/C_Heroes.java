package ATried.Round_80;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_Heroes {

    /**
     * Tags: Brute Force, Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Liking between heros
        int t1 = 0; // Anka
        int t2 = 0; // Chapay
        int t3 = 0; // Cleo
        int t4 = 0; // Troll
        int t5 = 0; // Dracul
        int t6 = 0; // Snowy
        int t7 = 0; // Hexadecimal
        for (int i = 0; i < n; i++) {
            String p = scan.next();
            scan.next();
            String q = scan.next();
        }
        int a = scan.nextInt(); // Experience for Mephisto
        int b = scan.nextInt(); // Experience for Diablo
        int c = scan.nextInt(); // Experience for Baal
    }
}
