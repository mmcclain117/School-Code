package ATried.Round_10;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class E_GreedyChange {

    /**
     * Tags: Contructive Algorithms
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Amount of coins face vlaues
        int a[] = new int[n]; // Face Values
        for (int i = 0; i < n; i++) {
            a[i] = scan.nextInt();
        }
    }
}
