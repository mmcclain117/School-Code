package ATried.Round_10;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class D_LCIS {

    /**
     * Tags: Dynamic Programming (Dp)
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Length of 1st Sequence
        int a[] = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = scan.nextInt();
        }
        int m = scan.nextInt(); // Length of 2nd Sequence
        int s[] = new int[m];
        for (int i = 0; i < m; i++) {
            s[i] = scan.nextInt();
        }
    }
}
