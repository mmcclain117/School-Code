package ATried.Round_10;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_PowerConsumptionCalculation {

    /**
     * Tags: Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int p1 = scan.nextInt(); // Normal Comsumption power
        int p2 = scan.nextInt(); // Saving consumption Power
        int p3 = scan.nextInt(); // Sleep Consumption Power
        int t1 = scan.nextInt(); // T min between p1 and p2
        int t2 = scan.nextInt(); // T min between p2 and p3
        int sum = 0;
        for (int i = 0; i < n; i++) {
            int l = scan.nextInt(); // Start time
            int r = scan.nextInt(); // End time
            int ti = r - l; // Time 
            if (ti > t1) {
                int nti = ti - t1;
                sum += (ti - nti) * p1;
                ti = nti;
            } else {
                sum += ti * p1;
                ti = 0;
            }
            if (ti < t2) {
                sum += ti * p2;
                ti = 0;
            } else {
                int nti = ti - t2;
                sum += (nti - ti) * p2;
                ti = nti;
            }
            if (ti > 0) {
                sum += p3 * ti;
            }
        }
        out.println(sum);
    }
}
