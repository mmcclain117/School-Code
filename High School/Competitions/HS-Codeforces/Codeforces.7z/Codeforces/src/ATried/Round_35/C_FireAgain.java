package ATried.Round_35;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_FireAgain {

    /**
     * Tags: Force, Similar, Paths,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(new File("input.txt"));

    }
}
