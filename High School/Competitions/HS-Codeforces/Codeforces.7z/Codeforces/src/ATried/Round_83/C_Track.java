package ATried.Round_83;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_Track {

    /**
     * Tags: Graphs, Greedy, Shortest Paths
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int m = scan.nextInt();
        int k = scan.nextInt();
        char grid[][] = new char[n][m];
        int sxp = 0; // Start X Point
        int syp = 0; // Start Y Point
        int exp = 0; // End X Point
        int eyp = 0; // End Y Point
        for (int i = 0; i < n; i++) {
            String s = scan.nextLine();
            char ch[] = s.toCharArray();
            for (int ii = 0; ii < ch.length; ii++) {
                grid[i][ii] = ch[ii];
                if (ch[ii] == 'S') {
                    sxp = i;
                    syp = ii;
                } else if (ch[ii] == 'T') {
                    exp = i;
                    eyp = ii;
                }
            }
        }
    }
}
