package ATried.Round_93;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_Frames {

    /**
     * Tags: Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Number of Folders
        int m = scan.nextInt();// Width of screen
        int a = scan.nextInt();// First folder
        int b = scan.nextInt(); // Last Folder

    }
}
