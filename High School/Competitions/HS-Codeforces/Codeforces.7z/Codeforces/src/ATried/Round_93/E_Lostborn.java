package ATried.Round_93;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class E_Lostborn {

    /**
     * Tags: Dp, Math,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
