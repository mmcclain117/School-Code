package ATried.Round_93;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class D_Flags {

    /**
     * Tags: Dp, Math, Matrices,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
