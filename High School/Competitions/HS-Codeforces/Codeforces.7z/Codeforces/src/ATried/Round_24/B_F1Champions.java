package ATried.Round_24;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class B_F1Champions {

    /**
     * Debug Tags: Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int t = scan.nextInt(); // Number of Races
//        scan.nextLine();
        ArrayList<String> pep = new ArrayList(); // Name of racers
        ArrayList<int[]> score = new ArrayList(); // Win Count
        for (int i = 0; i < t; i++) {
            int ra = scan.nextInt(); // Number of racers in the race
            scan.nextLine();
            for (int ii = 0; ii < ra; ii++) {
                String race = scan.nextLine(); // Racer
                if (pep.contains(race)) {
                    int te[] = score.get(pep.indexOf(race));
                    te[i]++;
                    score.set(pep.indexOf(race), te);
                } else {
                    int te[] = new int[10];
                    te[i]++;
                    pep.add(race);
                    score.add(te);
                }
            }
        }
        ArrayList<Integer> s = getSums(score);// Sums
        ArrayList<Integer> gw = getWins(score); // Geting wins
        int top = Collections.max(s); // Winner Sum count
        int topw = Collections.max(gw); // Win Match count
//        int b = s.size(); // Before Size
        int counting = count(s, top); // Counts Number of winners
        int cw = count(gw, topw); // OCount winning Matches
        if (counting == 1) { // only one top person
//        if (b - 1 == s.size()) {
            System.out.println(Arrays.toString(s.toArray()));
            System.out.println(s.indexOf(top));
//            System.out.println(Arrays.toString(score.toArray()));
            System.out.println(score.indexOf(top));
            System.out.println(pep.get(s.indexOf(top)));
        } else {// there is a tie
//            int p1 = s.remove(s.indexOf(top));
//            int p2 = s.remove(s.indexOf(top));
            int p1 = s.remove(s.indexOf(score.indexOf(top)));
            int p2 = s.remove(s.indexOf(score.indexOf(top)));
            int ti = tieBreak(score.get(p1), score.get(p2));
            if (ti == 1) {
                System.out.println(pep.get(p1));
            } else if (ti == 2) {
                System.out.println(pep.get(p2));
            }
        }
        if (cw == 1) { // only one top person
//            System.out.println(pep.get(s.get(score.indexOf(topw))));
//            System.out.println(pep.get(s.indexOf(topw)));
//            System.out.println(gw.indexOf(topw));
            System.out.println(pep.get(gw.indexOf(topw)));
//            System.out.println(topw);
        } else {// there is a tie
            int p1 = s.remove(s.indexOf(top));
            int p2 = s.remove(s.indexOf(top));
            int ti = tieBreak(score.get(p1), score.get(p2));
            if (ti == 1) {
                System.out.println(pep.get(p1));
            } else if (ti == 2) {
                System.out.println(pep.get(p2));
            }
        }
    }

    private static int count(ArrayList<Integer> s, int top) {
        int sum = 0;
        for (int p : s) {
            if (top == p) {
                sum++;
            }
        }
        return sum;
    }

    public static ArrayList<Integer> getWins(ArrayList<int[]> a) {
        ArrayList<Integer> k = new ArrayList();
        for (int i = 0; i < a.size(); i++) {
            int p[] = a.get(i);
            int sum = 0;
            for (int ii = 0; ii < p.length; ii++) {
                sum += p[ii];
            }
            k.add(sum);
        }
        return k;
    }

    public static ArrayList<Integer> getSums(ArrayList<int[]> a) {
        int uu[] = {25, 18, 15, 12, 10, 8, 6, 4, 2, 1};
        ArrayList<Integer> k = new ArrayList();
        for (int i = 0; i < a.size(); i++) {
            int p[] = a.get(i);
            int sum = 0;
            for (int ii = 0; ii < p.length; ii++) {
                sum += p[ii] * uu[ii];
            }
            k.add(sum);
        }
        return k;
    }

    private static int tieBreak(int[] p1, int[] p2) {
        int con = 0;
        while (true) {
            if (p1[con] == p2[con]) {
                con++;
            } else if (p1[con] > p2[con]) {
                return 1;
            } else {
                return 2;
            }
        }
    }
}
