package ATried.Round_24;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_RingRoad {

    /**
     * Tags: Graphs
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();// Amount of cities
        int gr[][] = new int[n][n];
        int set[][] = new int[n][3];
        for (int x = 0; x < n; x++) {
            int a = scan.nextInt(); // City A
            int b = scan.nextInt(); // City B
            int c = scan.nextInt(); // Cost
//            set[x][0] = a; // City A
//            set[x][1] = b; // City B
//            set[x][2] = c; // Cost
            gr[a][b] = c;
        }
        for (int i = 0; i < n; i++) {
            for (int ii = 0; ii < n; ii++) {
                System.out.print(gr[i][ii] + " ");
            }
            System.out.println();
        }
    }
}
