package ATried.Round_24;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_SequenceOfPoints {

    /**
     * Tags: Geometry, Implementation, Math
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int j = scan.nextInt();
        int mx0 = scan.nextInt();
        int my0 = scan.nextInt();

    }
}
