package ATried.Round_24;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class D_BrokenRobot {

    /**
     * Tags: Dynamic Programming (Dp), Probabilities
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int m = scan.nextInt();
        int i = scan.nextInt();
        int j = scan.nextInt();

    }
}
