package ATried.Round_86;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class E_LongSequence {

    /**
     * Tags: Force, Math, Matrices,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
