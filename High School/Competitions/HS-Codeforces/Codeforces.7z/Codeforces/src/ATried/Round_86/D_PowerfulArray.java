package ATried.Round_86;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class D_PowerfulArray {

    /**
     * Tags: Structures, Implementation, Math, Pointers,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
