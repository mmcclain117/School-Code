package ATried.Round_92;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_BinaryNumber {

    /**
     * Runtime error Tags: Greedy
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        String a = scan.nextLine();
        int con = 0;
        while (!a.equals("1")) {
            if (a.charAt(a.length() - 1) == '1') { // Add 1
                int i = a.length() - 1;
                while (i > 0 && a.charAt(i) == '1') {
//                for (int i = a.length() -1 ; i >0 ;i--) {
//                    if (a.charAt(i) == '1') {
                    i--;
//                    }
                }
                con++;
//                System.out.println(a.substring(0, i));
                if (i == 0) {
                    a = "1" + (a.substring(i).replaceAll("1", "0"));
                } else {
                    a = a.substring(0, i) + "1" + (a.substring(i + 1).replaceAll("1", "0"));
                }
//                System.out.println(a + " " + con);
            } else {
                int i = a.length() - 1;
                while (i > 0) {
//                for (int i = a.length() -1 ; i >0 ;i--) {
                    if (a.charAt(i) == '0') {
                        con++;
                    } else {
                        break;
                    }
                    i--;
                }
                a = a.substring(0, i + 1);
//                System.out.println(a + " " + con);
            }
        }
        System.out.println(con);
    }
}
