package ATried.Round_92;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_NewspaperHeadline {

    /**
     * Tags: Binary Search, Data Structures, Dynamic Programming (Dp), Greedy
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        String a = scan.nextLine();
        String b = scan.nextLine();
    }
}
