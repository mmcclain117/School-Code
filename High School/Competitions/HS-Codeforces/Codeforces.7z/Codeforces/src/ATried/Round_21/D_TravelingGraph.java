package ATried.Round_21;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class D_TravelingGraph {

    /**
     * Tags: Bitmasks, Graph Matchings, Graphs,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Number of Vertices
        int m = scan.nextInt(); // Number of Edges
        int x[] = new int[m]; // X edge endpoint
        int y[] = new int[m]; // Y edge endpoint
        int w[] = new int[m]; // Edge length
        for (int i = 0; i < m; i++) {
            x[i] = scan.nextInt();
            y[i] = scan.nextInt();
            w[i] = scan.nextInt();
        }
    }
}
