package ATried.Round_21;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_Intersection {

    /**
     * Tags: Implementation, Math
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int a1 = scan.nextInt();
        int b1 = scan.nextInt();
        int c1 = scan.nextInt();
        int a2 = scan.nextInt();
        int b2 = scan.nextInt();
        int c2 = scan.nextInt();

    }
}
