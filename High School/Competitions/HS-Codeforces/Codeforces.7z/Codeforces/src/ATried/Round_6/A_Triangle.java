package ATried.Round_6;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_Triangle {

    /**
     * Tags: Brute Force, Geometry
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int a1 = scan.nextInt();
        int a2 = scan.nextInt();
        int a3 = scan.nextInt();
        int a4 = scan.nextInt();
//        Notice which one of the sticks you dont use
//        Define degenrate triangle
//        Look all of those solutions
    }
}
