package ATried.Round_6;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_AliceBobAndChocolate {

    /**
     * Tags: Greedy, Two Pointers
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int t[] = new int[n];
        for (int i = 0; i < n; i++) {
            t[i] = scan.nextInt();
        }
    }
}
