package ATried.Round_6;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class D_LizardsAndBasements {

    /**
     * Tags: Force, Dp,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
