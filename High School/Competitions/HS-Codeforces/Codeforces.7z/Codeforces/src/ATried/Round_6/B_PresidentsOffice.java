package ATried.Round_6;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_PresidentsOffice {

    /**
     * Tags: Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Length
        int m = scan.nextInt(); // Width
        char c = scan.next().charAt(0); // Desk Color

    }
}
