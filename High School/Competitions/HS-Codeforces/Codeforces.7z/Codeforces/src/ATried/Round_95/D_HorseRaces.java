package ATried.Round_95;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class D_HorseRaces {

    /**
     * Tags: Dp, Math,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
