package ATried.Round_95;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_Hockey {

    /**
     * Tags: Implementation, Strings,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Forbiden string in seciton
        String a[] = new String[n];
//        scan.nextLine();
        for (int i = 0; i < n; i++) {
            a[i] = scan.nextLine();
        }
        String ph = scan.nextLine(); // Phrase
        char l = scan.next().charAt(0); // Letter
    }
}
