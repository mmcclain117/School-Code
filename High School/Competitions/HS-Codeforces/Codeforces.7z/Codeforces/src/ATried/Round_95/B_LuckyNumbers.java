package ATried.Round_95;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_LuckyNumbers {

    /**
     * Tags: Dynamic Programming (Dp), Greedy
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        if (n > 75 && n < 4476) {
            System.out.println(4477);
        } else {
            while (true) {
                if ((n + "").length() % 2 == 0) {
                    if (superLuckey(n)) {
                        System.out.println(n);
                        break;
                    } else {
                        n++;
                    }
                } else {
                    n++;
                }
            }
        }
    }

    private static boolean superLuckey(int n) {
        char ch[] = (n + "").toCharArray();
        int f = 0; // Count of four
        int s = 0;// Count of Seven
        for (int i = 0; i < ch.length; i++) {
            if (ch[i] == '4') {
                f++;
            } else if (ch[i] == '7') {
                s++;
            } else {
                return false;
            }
        }
        return f == s;
    }
}
