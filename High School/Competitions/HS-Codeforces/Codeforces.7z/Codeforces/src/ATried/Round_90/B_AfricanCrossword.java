package ATried.Round_90;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_AfricanCrossword {

    /**
     * Tags: Implementation, Strings
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int m = scan.nextInt();
        char ch[][] = new char[m][n];
    }
}
