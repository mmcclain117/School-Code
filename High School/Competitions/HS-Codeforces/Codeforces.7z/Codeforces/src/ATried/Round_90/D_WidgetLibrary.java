package ATried.Round_90;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class D_WidgetLibrary {

    /**
     * Tags: None
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
