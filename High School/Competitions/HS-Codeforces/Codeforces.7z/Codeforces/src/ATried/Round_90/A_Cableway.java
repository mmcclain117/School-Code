package ATried.Round_90;

import static java.lang.Math.ceil;
import java.util.Scanner;

public class A_Cableway {

    /**
     * Tags: Greedy, Math
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int r = scan.nextInt();
        int b = scan.nextInt();
        int g = scan.nextInt();
        int rc = (int) ceil((double) r / 2);
        int bc = (int) ceil((double) r / 2);
        int gc = (int) ceil((double) r / 2);
    }
}
