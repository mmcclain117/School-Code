package ATried.Round_36;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_Fractal {

    /**
     * Tags: Implementation,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(new File("input.txt"));

    }
}
