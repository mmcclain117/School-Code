package ATried.Round_25;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_IQTest {

    /**
     * Tags: Brute Force
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Number of tasks
        int s[] = new int[n]; // Set of numbers
        for (int i = 0; i < n; i++) {
            s[i] = scan.nextInt();
        }
    }
}
