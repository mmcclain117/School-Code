package ATried.Round_25;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class D_RoadsNotOnlyInBerland {

    /**
     * Tags: Dsu, Graphs, Trees
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Amount of cities
        for (int i = 0; i < n - 1; i++) {
            int a = scan.nextInt(); // First city connects
            int b = scan.nextInt(); // Second city connects
        }
    }
}
