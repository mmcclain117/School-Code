package ATried.Round_25;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class B_PhoneNumbers {

    /**
     * Tags: Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Number of digits
        String s = scan.nextLine(); // The number
        char ch[] = s.toCharArray();
        String d[] = new String[n / 2]; // Seperated numbers
        int cond = 0; // Placement of d
        /*
         for (int i = 0; i < n; i++) {
         if ((n - i) == 2 || (n - i) == 3) {
         d[cond] = s.substring((n - i));
         } else {
         if (ch[i] == ch[i + 1]) {
         if ((i + 2) < n && (n - i + 2) % 3 == 0 || (n - i + 2) % 2 == 0) { // If they can do the last set
         if (ch[i + 1] == ch[i + 2]) {
         }
         }
         }
         }
         }
         */
    }
}
