package ATried.Round_25;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class E_Test {

    /**
     * Tags: Hashing, Strings
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        String s1 = scan.nextLine();
        String s2 = scan.nextLine();
        String s3 = scan.nextLine();
    }
}
