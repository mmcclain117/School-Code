package ATried.Round_87;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_InterestingGame {

    /**
     * Tags: Dp, Games,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
