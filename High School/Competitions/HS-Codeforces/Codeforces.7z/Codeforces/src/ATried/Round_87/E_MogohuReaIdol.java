package ATried.Round_87;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class E_MogohuReaIdol {

    /**
     * Tags: Geometry,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
