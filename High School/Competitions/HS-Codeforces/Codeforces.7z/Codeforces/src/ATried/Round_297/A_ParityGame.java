package ATried.Round_297;

import java.util.Scanner;
import java.util.ArrayList;

public class A_ParityGame {

    /**
     * Tags: Contructive Algorithms
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        String a = scan.nextLine();
        String b = scan.nextLine();
        String ta = "";
        int bb = count(b);
        ArrayList ar = new ArrayList();
        while (!(ta.equals(b))) {

        }
    }

    private static int count(String a) {
        char ch[] = a.toCharArray();
        int con = 0;
        for (char c : ch) {
            if (c == '1') {
                con++;
            }
        }
        return con;
    }

    private static String add(String a) {
        a += "0";
        return a;
    }

    private static String sub(String a) {
        return a.substring(1);
    }
}
