package ATried.Round_297;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class E_MysticCarvings {

    /**
     * Tags: Structures,
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);

    }
}
