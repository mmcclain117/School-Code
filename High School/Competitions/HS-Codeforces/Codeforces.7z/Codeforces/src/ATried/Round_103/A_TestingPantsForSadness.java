package ATried.Round_103;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_TestingPantsForSadness {

    /**
     * Tags: Greedy, Implementation, Math
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Number of Questions
        int a[] = new int[n];
        long sum = 0;
//        int one = 0;
        for (int i = 0; i < n; i++) {
            a[i] = scan.nextInt();
//            int te = scan.nextInt();
            long t = i * (a[i] - 1);
            if (t < 0) {
//                t = 0;
                t = i;
            }
//            sum += a[i] + (i * (a[i] - 1));
            sum += a[i] + t;
//            if (a[i] == 1) {
//                one++;
//            }
        }
//        if (a[n - 1] == 1) {
//            one--;
//        }
//        out.println(sum - one);
        out.println(sum);
//        int con = 0;
//        if (n == 1) {
//            out.println(a[0]);
//        } else {
//            int tot = 0;
//            int q = 0;
//            while (con < n) {
//                tot += a[con];
//                tot += q;
//                con++;
//                q++;
//            }
//            out.println(tot);
//        }
    }
}
