package ATried.Round_32;

import static java.lang.System.out;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;

public class D_Constellation {

    /**
     * Tags: Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int m = scan.nextInt();
        int k = scan.nextInt();
        scan.nextLine();
        char gr[][] = new char[n][m];
        ArrayList<Integer> xx = new ArrayList();
        ArrayList<Integer> yy = new ArrayList();
        for (int y = 0; y < n; y++) {
            String te = scan.nextLine();
            char ch[] = te.toCharArray();
            for (int x = 0; x < m; x++) {
                gr[y][x] = ch[x];
            }
//            out.println(ch.length);
        }
//        int k1 = k - 1;
        int k2 = k + 1;
//        out.println(k);
        for (int y = 0; y < n; y++) {
//        for (int y = k1; y < n - k1; y++) {
            for (int x = 0; x < m; x++) {
//            for (int x = k1; x < m - k1; x++) {
                if (gr[y][x] == '*') {
                    xx.add(x);
                    yy.add(y);
                }
            }
        }
//        int con =0;
        boolean was = false;
        for (int i = 0; i < xx.size(); i++) {
            try {
                boolean up = gr[yy.get(i) - k][xx.get(i)] == '*';
                boolean down = gr[yy.get(i) + k][xx.get(i)] == '*';
                boolean left = gr[yy.get(i)][xx.get(i) - k] == '*';
                boolean right = gr[yy.get(i)][xx.get(i) + k] == '*';
                if (up && down && left && right) {
                    out.println(((yy.get(i)) + 1) + " " + (xx.get(i) + 1)); // Center
//                    out.println(((yy.get(i) - k) + 1) + " " + (xx.get(i) + 1)); // Up
                    out.println(((yy.get(i) - k)) + " " + (xx.get(i) + 1)); // Up
//                    out.println(((yy.get(i) + k) + 1) + " " + (xx.get(i) + 1)); // Down
                    out.println(((yy.get(i) + k2)) + " " + (xx.get(i) + 1)); // Down
                    out.println(((yy.get(i)) + 1) + " " + (xx.get(i - k) + 1)); // Left
                    out.println(((yy.get(i)) + 1) + " " + (xx.get(i + k) + 1)); // Right
                    was = true;
                    out.println(i + " " + xx.get(i) + " " + yy.get(i));
//                    break;
                }
            } catch (ArrayIndexOutOfBoundsException e) {
                xx.remove(i);
                yy.remove(i);
                i--;
            }
        }
        if (!was) {
            out.println("-1");
        }
        out.println(Arrays.toString(xx.toArray()));
        out.println(Arrays.toString(yy.toArray()));
        out.println();
//        Five integers that are meating the standard positions
//        gr[2][5] = '&';
//        gr[1][5] = '&';
//        gr[3][5] = '&';
//        gr[2][4] = '&';
//        gr[2][5] = '&';
//        for (int y = 0; y < n; y++) {
//            for (int x = 0; x < m; x++) {
//                out.print(gr[y][x] + "");
//            }
//            out.println();
//        }
    }
}
