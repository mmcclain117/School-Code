package ATried.Round_32;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_Flea {

    /**
     * Tags: Math
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt(); // Length
        int m = scan.nextInt();// Width
        int s = scan.nextInt();// Fleas Jump
        int sum = 0;
        if (s >= n && s >= m) {
            sum = n * m;
        } else {
            if (s >= n) {
                sum = n * s;
            } else if (s >= m) {
                sum = m * s;
            } else {
                sum = s * s;
            }
        }
        out.println(sum);
    }
}
