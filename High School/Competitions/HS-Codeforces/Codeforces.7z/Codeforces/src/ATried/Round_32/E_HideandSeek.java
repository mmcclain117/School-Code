package ATried.Round_32;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class E_HideandSeek {

    /**
     * Tags: Geometry, Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int xv = scan.nextInt();// X Victor
        int yv = scan.nextInt();// Y Victor
        int xp = scan.nextInt();// X Peter
        int yp = scan.nextInt();// Y Peter
        int xw1 = scan.nextInt();// X Wall 1
        int yw1 = scan.nextInt();// Y Wall 1
        int xw2 = scan.nextInt();// X Wall 2
        int yw2 = scan.nextInt();// Y Wall 2
        int xm1 = scan.nextInt();// X Mirror 1
        int ym1 = scan.nextInt();// Y Mirror 1
        int xm2 = scan.nextInt();// X Mirror 2
        int ym2 = scan.nextInt();// Y Mirror 2

//        Check V to P
//        Check V to Mirror 1
//        Check V to Mirror 2
//        Check P to Mirror 1 
//        Check P to Mirror 2
    }
}
