package ATried.Round_106;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class C_Buns {

    /**
     * Tags: Chinese Remainder Theorem, Geometry
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int m = scan.nextInt();
    }
}
