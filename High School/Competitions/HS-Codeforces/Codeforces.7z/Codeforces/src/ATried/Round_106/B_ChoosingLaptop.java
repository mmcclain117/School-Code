package ATried.Round_106;

import java.util.Scanner;

public class B_ChoosingLaptop {

    /**
     * Tags: Brute Force, Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int speed[] = new int[n];
        int ram[] = new int[n];
        int hdd[] = new int[n];
        int cost[] = new int[n];
        int tot[] = new int[n];
        int maxS = 0;
        int maxR = 0;
        int maxH = 0;
        int minC = 0;
        for (int i = 0; i < n; i++) {
            speed[i] = scan.nextInt();
            ram[i] = scan.nextInt();
            hdd[i] = scan.nextInt();
            cost[i] = scan.nextInt();
            if (speed[i] > maxS) {
                maxS = speed[i];
            }
            if (ram[i] > maxR) {
                maxR = ram[i];
            }
            if (hdd[i] > maxH) {
                maxS = hdd[i];
            }
            if (cost[i] < minC) {
                minC = cost[i];
            }
        }
    }
}
