package ATried.Round_106;

import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;

public class A_CardGame {

    /**
     * Tags: Implementation
     *
     * @param args
     */
    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        String a = scan.nextLine();
        String h1 = scan.next();
        String h2 = scan.next();
        if (h1.substring(1).equals(a) && (!(h2.substring(1).equals(a)))) {
            out.println("YES");
        } else if (h2.substring(1).equals(a) && (!(h1.substring(1).equals(a)))) {
            out.println("NO");
        } else {
            char c1 = h1.charAt(0);
            char c2 = h2.charAt(0);
            if (c1 == 'T') {
                c1 -= 26;
            } else if (c1 == 'J') {
                c1 -= 15;
            } else if (c1 == 'Q') {
                c1 -= 21;
            } else if (c1 == 'K') {
                c1 -= 14;
            } else if (c1 == 'A') {
                c1 -= 3;
            }
            if (c2 == 'T') {
                c2 -= 26;
            } else if (c2 == 'J') {
                c2 -= 15;
            } else if (c2 == 'Q') {
                c2 -= 21;
            } else if (c2 == 'K') {
                c2 -= 14;
            } else if (c2 == 'A') {
                c2 -= 3;
            }
            if (c1 > c2) {
                out.println("YES");
            } else {
                out.println("NO");
            }
//            out.println(((int) '6'));
//            out.println(((int) '9'));
//            out.println(((int) 'T') - 26);
//            out.println(((int) 'J') - 15);
//            out.println(((int) 'Q') - 21);
//            out.println(((int) 'K') - 14);
//            out.println(((int) 'A') - 3);
//            out.println(c1 + " " + (int) c1);
//            out.println(c2 + " " + (int) c2);
        }
    }
}
