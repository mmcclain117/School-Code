package projects.critters;

import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;
import java.util.ArrayList;
import java.awt.Color;

public class BlusterCritter extends Critter {

    private int courageFactor;

    public BlusterCritter(int c) {
        super();
        courageFactor = c;
    }

    @Override
    public ArrayList<Actor> getActors() {
        ArrayList<Actor> actors = new ArrayList();
        Location loc = getLocation();
        for (int r = loc.getRow() - 2; r <= loc.getRow() + 2; r++) {
            for (int c = loc.getCol() - 2; c <= loc.getCol() + 2; c++) {
                Location tempLoc = new Location(r, c);
                if (getGrid().isValid(tempLoc)) {
                    Actor a = getGrid().get(tempLoc);
                    if (a != null && a != this) {
                        actors.add(a);
                    }
                }
            }
        }
        return actors;
    }

    @Override
    public void processActors(ArrayList<Actor> actors) {
        int count = 0;
        for (Actor a : actors) {
            if (a instanceof Critter) {
                count++;
            }
        }
        if (count < courageFactor) {
            lighten();
        } else {
            darken();
        }
    }

    private void darken() {
        Color c = getColor();
        int r = c.getRed();
        int g = c.getGreen();
        int b = c.getBlue();
        if (r > 0) {
            r--;
        }
        if (g > 0) {
            g--;
        }
        if (b > 0) {
            b--;
        }
        setColor(new Color(r, g, b));
    }

    private void lighten() {
        Color c = getColor();
        int r = c.getRed();
        int g = c.getGreen();
        int b = c.getBlue();
        if (r < 255) {
            r++;
        }
        if (g < 255) {
            g++;
        }
        if (b < 255) {
            b++;
        }
        setColor(new Color(r, g, b));
    }
}
