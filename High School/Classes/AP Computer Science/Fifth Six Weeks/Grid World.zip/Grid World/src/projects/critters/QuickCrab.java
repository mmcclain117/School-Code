
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import java.awt.Color;
import java.util.ArrayList;
import projects.critters.CrabCritter;

public class QuickCrab extends CrabCritter {

    public QuickCrab() {
        setColor(Color.CYAN);

    }

    public ArrayList<Location> getMoveLocations() {
        ArrayList<Location> locations = new ArrayList();
        Grid g = getGrid();
        addIfGoodTwoAwayMove(locations, getDirection() + Location.LEFT);
        addIfGoodTwoAwayMove(locations, getDirection() + Location.RIGHT);
        if (locations.isEmpty()) {
            return super.getMoveLocations();
        }
        return locations;
    }

    private void addIfGoodTwoAwayMove(ArrayList<Location> locs, int direct) {
        Grid g = getGrid();
        Location loc = getLocation();
        Location temp = loc.getAdjacentLocation(direct);
        if (g.isValid(temp) && g.get(temp) == null) {
            Location loc2 = temp.getAdjacentLocation(direct);
            if (g.isValid(loc2) && g.get(loc2) == null) {
                locs.add(loc2);
            }
        }
    }
}
