package projects.boxBug;

import info.gridworld.actor.*;
import info.gridworld.grid.Location;

/**
 *
 * @author Jacob
 */
public class Jumper2 extends Bug {

    public boolean possible;
    private ActorWorld w;
    private int direction;

    Jumper2() {
        possible = false;
        direction = Location.AHEAD;
    }

    @Override
    public void act() {
        /*
         possible = super.canMove();
         Location l = super.getLocation();
         Location l1 = new Location(l.getRow() + 2, l.getCol());
         Location l2 = l1.getAdjacentLocation(direction);
         //        possible = null;
         if (possible) {
         //            move();
         //            super.moveTo(new Location(super.getLocation().getRow() + (direction * 1), super.getLocation().getCol()));
         super.moveTo(new Location(super.getLocation().getRow() + 2, super.getLocation().getCol()));
         } else {
         super.getGrid().isValid(l2);
         if (super.getGrid().isValid(l2)) {
         //                super.moveTo(new Location(super.getLocation().getRow() + (direction * 1), super.getLocation().getCol()));
         move();
         //                move();
         } else {
         turn();
         }
         }
         */
//        for (int r = 0 ; r < getGrid().getNumCols() ; r += 2) {
//            for (int c = 0 ; c < getGrid().getNumRows() ; c += 2) {
        Location l = getLocation();
        Location l2 = l.getAdjacentLocation(direction).getAdjacentLocation(direction);
        Location l3 = l.getAdjacentLocation(direction).getAdjacentLocation(direction).getAdjacentLocation(direction);
        if (getGrid().isValid(l2)) {
            moveTo(l2);
            getGrid().put(l, new Flower());
        } else if (getGrid().isValid(l3)) {
            moveTo(l2);
            getGrid().put(l, new Flower());
        } else {
            turn();
        }
//                super.putSelfInGrid(super.getGrid(), l);
//            }
//        }
    }
}
