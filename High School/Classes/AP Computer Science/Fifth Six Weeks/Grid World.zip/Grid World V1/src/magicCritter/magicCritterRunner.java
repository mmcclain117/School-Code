package magicCritter;

import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Location;

public class magicCritterRunner {

    public static void main(String[] args) {
//        ActorWorld aw = new ActorWorld();
        ActorWorld world = new ActorWorld();
//        SpiralBug alice = new SpiralBug(2);
        magicCritter a = new magicCritter(0);
//        alice.setColor(Color.ORANGE);
//        SpiralBug bob = new SpiralBug(3);
//        world.add(new Location(7, 8), alice);
//        world.add(new Location(5, 5), bob);
        world.add(new Location(2, 3), new Rock());
//        world.add(new Location(0, 1), new Flower());
        world.add(new Location(1, 2), a);
        world.show();
    }
}
