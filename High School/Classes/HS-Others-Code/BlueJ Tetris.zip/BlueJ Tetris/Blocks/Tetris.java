

import javax.swing.*;
import java.awt.*;
public class Tetris {

    JLabel statusbar;
    JFrame f;
    public Tetris() {
        f = new JFrame();
        statusbar = new JLabel(" 0");
        f.add(statusbar, BorderLayout.SOUTH);
        f.setSize(200, 400);
        Block b = new Block();
        f.setTitle("Tetris");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);
    }

    public JLabel getStatusBar() {
        return statusbar;
    }

    public static void main(String[] args) {
        Tetris game = new Tetris();
    }
}
