 package WorkingGame;

import javax.swing.*;
import java.awt.*;
public class TetrisWork {

    JLabel statusbar;
    JFrame f;
    public TetrisWork() {
        f = new JFrame();
        statusbar = new JLabel(" 0");
        f.add(statusbar, BorderLayout.SOUTH);
        Board board = new Board(this);
        f.add(board);
        board.start();
        
        f.setBackground(Color.black);
        
        f.setSize(200, 400);
        f.setTitle("Tetris");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);
    }

    public JLabel getStatusBar() {
        return statusbar;
    }

    public static void main(String[] args) {
        TetrisWork game = new TetrisWork();
    }
}
