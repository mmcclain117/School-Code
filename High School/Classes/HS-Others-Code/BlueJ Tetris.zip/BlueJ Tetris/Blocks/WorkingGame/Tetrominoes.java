package WorkingGame;
/*
 * used for the Different types of blocks
 */
enum Tetrominoes {
    NoShape, ZShape, SShape, LineShape,
    TShape, SquareShape, LShape, MirroredLShape
};
